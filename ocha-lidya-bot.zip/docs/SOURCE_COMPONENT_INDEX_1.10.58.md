# Source Component Index — Ocha v1.10.58

This index records the menu-design changes against the extracted v1.10.57 operator snapshot. Paths and exports below were checked against the packaged source tree. It does not claim GitHub synchronization or live WhatsApp activation.

| Component ID | Component | Source and key functions | Inputs / outputs | Dependencies and side effects | Tests / status |
|---|---|---|---|---|---|
| `MENU-RENDER-001` | Text menu renderer and design system | `src/core/menu-renderer.js` — `commandInventory`, `sortCommands`, `buildMenuText`, `getMenuStats`, `getMenuPageCount`, `applyMenuFont`, `getMenuTemplate` | Plugin descriptors + config + prefixes + page metadata → deterministic WhatsApp menu text | Uses shipped menu settings; no network, filesystem, or process side effects | `test/menu-renderer.test.js`, `test/menu-settings.test.js`, `test/menu-design-settings.test.js` — TESTED |
| `MENU-PLUGIN-001` | Native-flow command menu | `src/plugins/general/menu.js` — `buildMenuButtonModel`, `sendInteractiveMenu`, `sendMenuPage`, `parseMenuArgs` | Live plugin registry, verified owner state, menu config, prefixes, socket/message → interactive category/command menu or text/banner fallback | `listPlugins`, config, prefixes, ButtonBuilder, reply-session pagination; command identifiers remain plain text | `test/menu-buttons.test.js`, `test/menu-real-plugin-inventory.test.js`, `test/menu-design-settings.test.js` — TESTED |
| `MENU-OWNER-001` | Global menu settings command | `src/plugins/owner/setmenu.js` — `buildSettingsSections`, `settingsSummary`, `showPicker`, `persistMenuSetting`, `execute` | Owner private-chat command args / native-flow selection → validated global menu config update | `isVerifiedOwnerMessage`, `getConfig`, `updateConfig`, `getPrefixes`, menu renderer presets; persists through `config.replace` event store | `test/menu-design-settings.test.js`, `test/menu-buttons.test.js` — TESTED |
| `CONFIG-MENU-001` | Menu configuration defaults and migration | `src/config.js` — `DEFAULTS`, `loadConfig`, `updateConfig`, `validateConfig` | Existing event-store config → schema v38 menu config with backwards-compatible defaults | JSONL database config event store; validation rejects unsupported template/font/order/spacing/border values | Menu renderer and new setmenu tests; TESTED |

## Menu configuration contract

`config.menu` contains `showDescriptions`, `template`, `font`, `order`, `spacing`, `topBorder`, `bottomBorder`, and `pagination.{enabled,pageSize}`. The shipped defaults are `corporate`, `normal`, `category`, spacing `0`, both borders enabled, descriptions disabled, and text fallback pagination disabled with a page size of 50.

The supported theme keys are `corporate`, `minimal`, `terminal`, `elegant`, `aurora`, `classic`, `compact`, `minimalist`, `cyberpunk`, `fantasy`, `ocean`, `sunset`, `emerald`, `sakura`, `monochrome`, and `royal`. Font keys are `normal`, `bolditalic`, `bold`, `sans`, `mono`, `superscript`, `double`, `smallcaps`, `fraktur`, `italic`, `script`, and `circled`. Sorting supports `category`, `az`, and `za`; spacing supports integers `0`–`3`; text page size supports integers `10`–`200`.

`.setmenu` keeps `ownerOnly: true` and `privateOnly: true` and verifies the configured owner against message sender metadata before writing. `.menu` continues to derive its command list from the live plugin registry; it does not maintain a parallel command registry. Native-flow command pages show at most seven command rows plus navigation rows to stay within the existing WhatsApp list contract. `pages` and `limit` govern the text fallback renderer; native-flow category navigation remains paginated when needed.

## Compatibility and non-goals

The Whiskay menu/settings implementation was read as a design reference only. No Whiskay dependencies, data files, business logic, menu widgets, profile/economy/energy integrations, custom image upload, or quoted-message experiments were copied. The Ocha menu banner remains `assets/menu-banner.jpg`. The private Ocha runtime and independent AC component were not modified by this menu release.
