## v1.10.58 — Menu design and owner setmenu — 2026-11-28

- Adapt selected menu presentation concepts from the supplied Whiskay project: 16 themes, 12 readable font presets, ordering, spacing and independent borders.
- Extend Ocha `config.menu` with schema v38 defaults and validation while preserving existing description and text-pagination preferences.
- Upgrade `.setmenu` into an interactive global settings directory; retain the `menuset` / `menuconfig` aliases and verified owner-private access.
- Preserve live plugin-registry discovery, native-flow row bounds, existing banner fallback, and plain ASCII executable command labels.
- No Whiskay runtime services/widgets or unrelated commands were imported. AC v2.1.1 runtime source was reviewed and left unchanged; only the paired compatibility metadata was advanced.
- See [`RELEASE_REPORT_1.10.58.md`](../RELEASE_REPORT_1.10.58.md) and [`SOURCE_COMPONENT_INDEX_1.10.58.md`](../SOURCE_COMPONENT_INDEX_1.10.58.md).

## v1.10.57 — Dual-repository automatic Git publication — 2026-11-27

- Retain the legacy Ocha `git:setup` and `git:watch` scripts and the original Ocha-only auto-sync service semantics.
- Add a second isolated auto-push lane rooted at `.private/artificial-consciousness-component`, with its own exact remote, branch `main`, and `AC_GITHUB_PAT`.
- Keep the parent Ocha Git root and watcher from staging or traversing any `.private/` content; add a regression that verifies the nested AC source remains private to the Ocha index.
- Add `npm run ac:git:setup`, which validates the canonical AC remote, preserves remote history by cloning before overlaying a newer local snapshot, and retains a backup. It rejects newer remote versions, same-version content mismatches, unexpected branches and symlinks.
- Add owner-private `.autopush` controls (aliases `.gitpush`, `.autogit`) with `menu: false`; persist only on/off flags in `.private/automation/auto-push.json`.
- Add separate token variables `GITHUB_PAT` and `AC_GITHUB_PAT`; neither value is stored in the config, remote URL, source, commit message or logs.
- Add two-target status/manual-push scripts and pre-restart flush for both lanes. No force-push or automatic divergent-history rewrite is allowed.
- AC remains v2.1.1: the mathematical/runtime model was reviewed but not altered in this operational integration release.
- Add tracked-private-index fail-closed guard, corrupt-config quarantine (both lanes OFF), and expanded AC credential/certificate/database exclusion rules.
- Add `AC_GITHUB_PAT` to environment inventory/configuration disclosure redaction; `.env.example` keeps a separate empty placeholder.
- See [`AUTO_PUSH_TWO_REPOSITORIES.md`](../AUTO_PUSH_TWO_REPOSITORIES.md) and the v1.10.57 release report for exact validation and limits.

## v1.10.56 — paired AC/NADI maintenance — 2026-11-26

- Pair Ocha with independent `ac-kernel-nadi@2.1.1` through the unchanged NADI HTTP API v1 contract.
- Update local sibling-component integration test to verify NADI 2.1.1.
- Update release builder to distinguish a verified Git-pinned component from a local source snapshot; no commit SHA is fabricated when workspace `.git` metadata is absent.
- Update private runtime package metadata to match Ocha v1.10.56; its preserved source modules are not modified.
- Carry forward the audited Lunara Pro contribution decision: held for source provenance, license, API contract and security gates; no runtime command/provider activated.
- Full paired QA results and source provenance are recorded in `docs/RELEASE_REPORT_1.10.56.md` and the independent AC maintenance report.

# Changelog Index

Current local paired operator snapshot: **Ocha v1.10.58 + AC v2.1.1**. Ocha v1.10.58 is a menu-only update over the v1.10.57 operator source; AC v2.1.1 runtime source was reviewed and left unchanged; only the paired compatibility metadata was advanced. See `RELEASE_REPORT_1.10.58.md` for build/test limits.

## v1.10.56 — Paired Artificial Consciousness maintenance

- Pair Ocha v1.10.56 with independent AC-Kernel NADI v2.1.1 over the unchanged NADI HTTP API v1.
- Update the local integration test to exercise the v2.1.1 sibling component.
- Keep the previous remote commit pin as fallback; the v2.1.1 local snapshot requires `OCHA_NADI_SOURCE_DIR=../artificial-consciousness-component`.
- Preserve the four immutable private-runtime source modules; only package metadata is synchronized to Ocha v1.10.56.
- Record the Lunara Pro contribution as analyzed and blocked pending original-file provenance, license and verified service contract; no provider or command is active.
- Two-base verification and snapshot provenance are detailed in `docs/RELEASE_REPORT_1.10.56.md` and the AC maintenance report.


The canonical, detailed release history is maintained in [`../CHANGE_LOG.md`](../CHANGE_LOG.md). This file is a release index only; do not maintain a second divergent changelog here. The repository root intentionally contains only `README.md` as a Markdown document.

Current paired local operator release: **Ocha v1.10.57 + AC v2.1.1** (source archive baseline: v1.10.51). The latest local migration separates four owner-designated modules into the external `@razzaqventures/ocha-private-runtime` package; see [`docs/PRIVATE_RUNTIME_EXTRACTION.md`](../PRIVATE_RUNTIME_EXTRACTION.md). See [`docs/REPOSITORY_AUDIT_1.10.51.md`](../REPOSITORY_AUDIT_1.10.51.md) for verification scope, test results, publication blockers and follow-up work.


## v1.10.55 — Environment Inventory Hardening

- Expand AST scanning coverage for project JavaScript, including root-level files, aliases, optional chaining and additional computed forms; record shell variable expansion and dotenv load/reload locations.
- Make `npm test`, `npm run check` and `npm run env:check` fail on unresolved computed environment access in production source; retain unresolved test accesses in the generated audit report.
- Refresh `.env.example` and `docs/ENVIRONMENT_VARIABLES.md` automatically on `npm start`, `npm run dev` and `npm test`; unknown discovered runtime keys are added as commented review entries only.
- Audit baseline: 313 JavaScript files, 3 shell files, 58 names, 260 named JS access sites, 9 shell expansion sites, 25 whole-environment pass-through sites, and 4 dotenv load/reload sites. No unresolved computed environment access was found in production source.

## v1.10.54 — AST Environment Inventory and Automatic .env.example Synchronization

- Add Acorn-based AST scanning for direct `process.env.KEY`, bracket access, destructuring, local environment aliases, provider-registry mappings and literal allowlists.
- Scan repository JavaScript source, tests, private runtime source, and shell tooling; report host variables, internal markers, test-only entries, unresolved computed reads and whole-environment process pass-through separately.
- Expand `.env.example` with the source-verified Ocha runtime settings and explicitly mark bootstrap/handoff values as internally managed rather than user configuration.
- Add `npm run env:sync` and `npm run env:check`; `npm start`, `npm run dev` and `npm test` automatically synchronize the template and `docs/ENVIRONMENT_VARIABLES.md`.
- Unknown production environment names are appended to a generated block as commented review items, preventing accidental activation or invented defaults.
- Add regression coverage for the `OCHA_HOST_PREFLIGHT_COMPLETED` marker, dynamic AI provider keys, computed access classification, shell overrides and generated artifact synchronization.

## v1.10.52 — Paired Two-Base Release and Runtime Operations

- Advance the Ocha operator base and its private runtime package to v1.10.52; preserve the four original private module byte fingerprints unchanged.
- Keep the complete operator-local `.private/` tree excluded from Git publication while including it in the explicitly local-only operator bundle.
- Build Ocha and the independent AC component with the single `npm run release:two-bases` orchestrator and emit a paired checksum manifest.
- Add `npm run maintain:two-bases` as the single verification/release entrypoint for JS syntax, docs, private-source integrity, publication audit, ACIE audit, Ocha regression tests, NADI API integration, AC Python tests, optional Prettier check and paired packaging.
- Retain the AC Python source as the independent `ac-kernel-nadi@2.1.0` base pinned to commit `16c2fa6e1b500745f260bcf091284a6e18726883`; do not copy it into the Ocha Node.js tree.
- Include read-only ACIE dynamic command/provider registry audit and local Ocha-to-NADI HTTP API v1 integration smoke test.
- Preserve the NADI findings on repeat-window MIMPI consolidation and large-`dt` INTEROCEPTION integration; no unverified formula changes were made.
- Verification: full Ocha suite 387 passed, 0 failed, 1 skipped; NADI integration 1/1; AC Python tests 4/4 and 9/9; private package integrity 3/3; publication scan 26 private files excluded. Live VPS provider state and live WhatsApp transport remain unverified without host/session access. Prettier is configured but not executed because the CLI was unavailable.

## v1.10.51 — Two-Base Operator Bundle and Local Private Core

- Co-locate the four immutable owner-private modules under `.private/ocha-private-runtime/`; preserve original/runtime byte copies and SHA-256 manifest.
- Load the bundled local private package before external package discovery; public Git clones without `.private` retain the public compatibility adapters.
- Add fail-closed private-runtime requirement, no-argument integrity verification, and source watcher exclusion.
- Add read-only ACIE dynamic command/provider health audit for VPS operations, including activation gate, aliases, health age, circuit state, sandbox probe and plugin loader visibility.
- Add one two-base release command that creates separate Ocha operator and AC component archives; the NADI Python source remains in its independent base and repository.
- Exclude `.private`, runtime data and credentials from future Git publication. Existing public Git history is not rewritten.


## v1.10.51 — Two-Base Operator Integration and ACIE Runtime Audit

- Keep the four private Ocha modules in the ignored local `.private/ocha-private-runtime/` package; public paths remain bounded compatibility facades and private `.test` is excluded from the public command menu.
- Preserve the Rizkyrohan contribution fixture in `.private/contributions/` with the original receipt and SHA-256; its attribution and review note remain in public documentation.
- Add one `release:two-bases` orchestrator to build the local operator Ocha bundle and independent AC component archive with checksums.
- Add a read-only ACIE dynamic registry/provider health audit and a local Ocha-to-NADI HTTP API v1 integration smoke test.
- Restore the two documented ACIE adapter modules and mark the owner message-test catalog as a plugin helper so the loader no longer treats it as a malformed command plugin.
- Validation: `npm test` 386 passed, 0 failed, 1 skipped (Baileys peer-dependent private import); focused NADI integration 1/1; Python AC tests 4/4 plus 9/9; private package integrity 3/3; syntax 286 JS files; docs 73 Markdown files; publication audit 26 private files excluded and no source fingerprint/credential findings.
- Actual VPS registry/provider state and live WhatsApp transport were not available in this source-only environment. Prettier execution is configured but was not run because its binary could not be installed here.


## Root layout cleanup — v1.10.52 maintenance

- Move this release index from the repository root to `docs/releases/CHANGELOG.md`.
- Move the project tree reference to `docs/architecture/PROJECT_STRUCTURE.md`.
- Move generated `OPERATOR_BUNDLE.json` metadata to `.release/OPERATOR_BUNDLE.json`; the release archive uses the same relative path.
- Keep only `README.md` as a root Markdown document; retain `package.json` and `.prettierrc.json` as appropriate root JSON metadata.


## Ocha Lidya v1.10.53 — Master eval output controls

- Added owner control `.master template on/off/status` to show or hide the JavaScript eval console frame without changing output content.
- Removed the `masterMaxOutput` truncation from JavaScript eval replies.
- Automatically deliver eval output longer than 30,000 characters as a UTF-8 TXT document quoted to the invoking message.
- Kept CLI, Python, and Go process output limits unchanged.
- Added regression tests for template visibility and TXT threshold routing.


## v1.10.53 — JavaScript eval output delivery

- Add `.master template on|off|status` to show or hide the JavaScript console frame; default is visible.
- Remove the configured output truncation from JavaScript eval results.
- Send complete eval output as a quoted UTF-8 TXT document when the rendered result exceeds 30,000 characters.
- Keep CLI, Python and Go output collector limits unchanged.
- Add six tests for template rendering, threshold behavior, inline delivery and full TXT document delivery.
- Advance private runtime package metadata to 1.10.53 without modifying the four immutable original source files.
- Keep Artificial Consciousness Component at v2.1.0 and update only its compatible Ocha release metadata to 1.10.53.
