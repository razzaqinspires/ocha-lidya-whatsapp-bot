# Environment Variable Inventory

Generated from the entire first-party Ocha tree using Acorn AST analysis. JavaScript files scanned: **325**; shell files scanned: **3**; distinct statically identified names: **59**.

> This is a source inventory, not a statement that every variable must be placed in `.env`. Internal markers and host-provided variables are identified separately. Secret values are never read by this scanner.

## Summary

| Classification | Names | Add to `.env.example`? |
|---|---:|---|
| Application configuration | 23 | Yes |
| Secret / credential | 8 | Yes, empty placeholder |
| Host / OS environment | 23 | No |
| Internal runtime marker | 4 | No; commented for reference |
| Test only | 1 | No |
| Preserved source only | 0 | No |

- Named JavaScript environment access sites: **272** total (259 statically resolved; 13 computed/unresolved). Static locations: 114 production and 145 test.
- Unresolved computed accesses: **13** total (0 production, 13 test).
- Shell environment expansion sites: **9**.
- Whole-environment pass-through call sites: **29**. These inherit host variables and do not represent individually named Ocha settings.
- Dotenv load/reload sites: **7**. The main bot entrypoint loads `.env` once through `dotenv/config`; the auto-Git watcher can reload it after a file change.

## Dotenv load and reload locations

| Source location | Mechanism |
|---|---|
| `scripts/ac-git-setup.js:1` | dotenv/config import |
| `scripts/ac-git-watch.js:1` | dotenv/config import |
| `scripts/git-sync-control.js:1` | dotenv/config import |
| `scripts/git-watch.js:1` | dotenv/config import |
| `scripts/refresh-ai-model-catalog.js:1` | dotenv/config import |
| `src/core/auto-git-sync.js:357` | dotenv.config() call |
| `src/index.js:1` | dotenv/config import |

`.env.example` is not loaded automatically; it is a safe template for creating `.env`. The application reads `.env` through `dotenv` imports/calls above.

## Static environment reads

| Name | Classification | Production source | Test source | Source locations |
|---|---|---:|---:|---|
| `AC_GITHUB_PAT` | Secret / credential | Yes | Yes | `scripts/ac-git-setup.js:123`, `src/core/ac-auto-git-sync.js:150`, `src/core/ac-auto-git-sync.js:171`, `src/core/ac-auto-git-sync.js:274`, `src/core/auto-git-sync.js:354`, `src/core/config-disclosure.js:59`, `test/owner-security.test.js:75`, `test/owner-security.test.js:77`, `test/owner-security.test.js:98`, `test/owner-security.test.js:99` |
| `CLOUDFLARED_BIN` | Application configuration | Yes | No | `src/rental/http-api.js:192` |
| `DEEPSEEK_API_KEY` | Secret / credential | Yes | Yes | `src/ai/providers.js:74`, `src/ai/providers.js:107`, `src/core/config-disclosure.js:59`, `test/ai-checkpoint-recovery.test.js:13`, `test/ai-free-policy.test.js:14`, `test/ai-free-policy.test.js:20`, `test/ai-speed.test.js:13`, `test/website-builder-integration.test.js:15` |
| `DYLD_LIBRARY_PATH` | Host / OS environment | Yes | No | `src/runtime/consciousness-runtime.js:58` |
| `FORCE_COLOR` | Host / OS environment | Yes | No | `src/core/logger.js:37`, `src/core/message-monitor.js:20` |
| `GEMINI_API_KEY` | Secret / credential | Yes | Yes | `src/ai/providers.js:74`, `src/ai/providers.js:107`, `src/core/config-disclosure.js:59`, `test/ai-checkpoint-recovery.test.js:13`, `test/ai-free-policy.test.js:14`, `test/ai-free-policy.test.js:19`, `test/ai-speed.test.js:13`, `test/ai-speed.test.js:60`, `test/website-builder-integration.test.js:15` |
| `GITHUB_PAT` | Secret / credential | Yes | No | `src/core/auto-git-sync.js:259`, `src/core/auto-git-sync.js:290`, `src/core/auto-git-sync.js:353`, `src/core/auto-git-sync.js:419`, `src/core/config-disclosure.js:59`, `src/runtime/nadi-component.js:171` |
| `GROQ_API_KEY` | Secret / credential | Yes | Yes | `src/ai/providers.js:74`, `src/ai/providers.js:107`, `src/core/config-disclosure.js:59`, `test/ai-checkpoint-recovery.test.js:12`, `test/ai-checkpoint-recovery.test.js:15`, `test/ai-checkpoint-recovery.test.js:51`, `test/ai-free-policy.test.js:14`, `test/ai-free-policy.test.js:18`, `test/ai-provider.test.js:16`, `test/ai-provider.test.js:18`, `test/ai-provider.test.js:50`, `test/ai-speed.test.js:12`, `test/ai-speed.test.js:15`, `test/ai-speed.test.js:59`, `test/ai-speed.test.js:79`, `test/website-builder-integration.test.js:14`, `test/website-builder-integration.test.js:17`, `test/website-builder-integration.test.js:80` |
| `HOME` | Host / OS environment | Yes | No | `src/master/dispatcher.js:35`, `src/runtime/code-lab.js:421`, `src/runtime/code-lab.js:911`, `src/runtime/code-lab.js:1204`, `src/runtime/code-lab.js:1322`, `src/runtime/consciousness-runtime.js:58` |
| `HOMEDRIVE` | Host / OS environment | Yes | No | `src/runtime/consciousness-runtime.js:58` |
| `HOMEPATH` | Host / OS environment | Yes | No | `src/runtime/consciousness-runtime.js:58` |
| `LANG` | Host / OS environment | Yes | No | `src/runtime/consciousness-runtime.js:58` |
| `LC_ALL` | Host / OS environment | Yes | No | `src/runtime/consciousness-runtime.js:58` |
| `LD_LIBRARY_PATH` | Host / OS environment | Yes | No | `src/runtime/consciousness-runtime.js:58` |
| `NEXORA_BOOTSTRAP_DRY_RUN` | Application configuration | Yes | No | `scripts/bootstrap/npm-deps.js:65` |
| `NO_COLOR` | Host / OS environment | Yes | No | `src/core/logger.js:36`, `src/core/message-monitor.js:19` |
| `npm_execpath` | Host / OS environment | Yes | No | `scripts/bootstrap/npm-deps.js:25` |
| `OCHA_AC_HEARTBEAT_MS` | Application configuration | Yes | No | `src/runtime/consciousness-runtime.js:10` |
| `OCHA_BOOTSTRAP_HANDOFF_CONSUMED` | Internal runtime marker | Yes | No | `src/runtime/bootstrap-agent.js:183`, `src/runtime/bootstrap-agent.js:184`, `src/runtime/bootstrap-agent.js:191` |
| `OCHA_HANDOFF_FROM_PID` | Internal runtime marker | Yes | No | `src/runtime/bootstrap-agent.js:183`, `src/runtime/bootstrap-agent.js:185`, `src/runtime/bootstrap-agent.js:192`, `src/runtime/code-lab.js:821`, `src/runtime/code-lab.js:864`, `src/runtime/code-lab.js:1406`, `src/runtime/single-instance.js:43` |
| `OCHA_HOST_BOOTSTRAP_FORCE` | Internal runtime marker | Yes | No | `src/runtime/bootstrap-agent.js:178`, `src/runtime/bootstrap-agent.js:179` |
| `OCHA_HOST_PREFLIGHT_COMPLETED` | Internal runtime marker | Yes | Yes | `src/index.js:69`, `src/runtime/code-lab.js:1385`, `test/code-lab-handoff-rollback.test.js:29`, `test/code-lab-handoff-rollback.test.js:32`, `test/code-lab-handoff-rollback.test.js:79`, `test/code-lab-handoff-rollback.test.js:80` |
| `OCHA_KERNEL_DASHBOARD_DIR` | Application configuration | Yes | No | `src/runtime/kernel-dashboard.js:11` |
| `OCHA_KERNEL_TELEMETRY_FILE` | Application configuration | Yes | Yes | `src/runtime/kernel-telemetry.js:4`, `test/kernel-telemetry.test.js:8`, `test/kernel-telemetry.test.js:13`, `test/kernel-telemetry.test.js:45` |
| `OCHA_NADI_API_TOKEN` | Secret / credential | Yes | No | `src/runtime/consciousness-runtime.js:61`, `src/runtime/consciousness-runtime.js:108`, `src/runtime/consciousness-runtime.js:128` |
| `OCHA_NADI_BASE_URL` | Application configuration | Yes | Yes | `src/runtime/consciousness-runtime.js:29`, `test/consciousness-runtime.test.js:47`, `test/consciousness-runtime.test.js:55`, `test/consciousness-runtime.test.js:63`, `test/nadi-component.test.js:26`, `test/nadi-component.test.js:34` |
| `OCHA_NADI_DATA_DIR` | Application configuration | Yes | No | `src/runtime/consciousness-runtime.js:79` |
| `OCHA_NADI_HOME` | Application configuration | Yes | Yes | `src/runtime/nadi-component.js:228`, `test/nadi-component.test.js:25`, `test/nadi-component.test.js:32` |
| `OCHA_NADI_PORT` | Application configuration | Yes | No | `src/runtime/consciousness-runtime.js:66` |
| `OCHA_NADI_REF` | Application configuration | Yes | Yes | `src/runtime/nadi-component.js:227`, `test/consciousness-runtime.test.js:48`, `test/consciousness-runtime.test.js:52`, `test/consciousness-runtime.test.js:64`, `test/nadi-component.test.js:13`, `test/nadi-component.test.js:24`, `test/nadi-component.test.js:31` |
| `OCHA_NADI_REPO_URL` | Application configuration | Yes | Yes | `src/runtime/nadi-component.js:226`, `test/consciousness-runtime.test.js:45`, `test/consciousness-runtime.test.js:51`, `test/consciousness-runtime.test.js:61`, `test/nadi-component.test.js:12`, `test/nadi-component.test.js:24`, `test/nadi-component.test.js:30` |
| `OCHA_NADI_SHA256` | Application configuration | Yes | Yes | `src/runtime/nadi-component.js:157`, `src/runtime/nadi-component.js:181`, `src/runtime/nadi-component.js:235`, `test/nadi-component.test.js:27`, `test/nadi-component.test.js:36` |
| `OCHA_NADI_SOURCE_DIR` | Application configuration | Yes | Yes | `src/runtime/nadi-component.js:219`, `test/consciousness-runtime.test.js:46`, `test/consciousness-runtime.test.js:54`, `test/consciousness-runtime.test.js:62`, `test/nadi-component.test.js:25`, `test/nadi-component.test.js:33` |
| `OCHA_NADI_UPDATE` | Application configuration | Yes | Yes | `src/runtime/nadi-component.js:155`, `src/runtime/nadi-component.js:234`, `src/runtime/nadi-component.js:244`, `test/nadi-component.test.js:26`, `test/nadi-component.test.js:35` |
| `OCHA_PRETTIER_BIN` | Application configuration | Yes | No | `src/core/auto-git-sync.js:17` |
| `OCHA_PRIVATE_RUNTIME_PATH` | Application configuration | Yes | Yes | `scripts/install-private-runtime.js:10`, `src/private-runtime/loader.js:40`, `test/private-runtime.test.js:16`, `test/private-runtime.test.js:19`, `test/private-runtime.test.js:124`, `test/private-runtime.test.js:139`, `test/private-runtime.test.js:147`, `test/private-runtime.test.js:157`, `test/private-runtime.test.js:158` |
| `OCHA_PRIVATE_RUNTIME_REQUIRED` | Application configuration | Yes | Yes | `scripts/install-private-runtime.js:17`, `scripts/private-runtime-status.js:6`, `src/private-runtime/loader.js:25`, `test/private-runtime.test.js:15`, `test/private-runtime.test.js:18`, `test/private-runtime.test.js:125`, `test/private-runtime.test.js:138`, `test/private-runtime.test.js:146`, `test/private-runtime.test.js:155`, `test/private-runtime.test.js:156` |
| `OCHA_PROJECT_LIBRARY_ROOT` | Application configuration | Yes | Yes | `src/ai/project-library.js:108`, `test/project-library.test.js:27`, `test/project-library.test.js:28`, `test/project-library.test.js:54`, `test/project-library.test.js:115`, `test/project-library.test.js:116`, `test/project-library.test.js:123`, `test/project-library.test.js:124`, `test/project-library.test.js:138`, `test/project-library.test.js:139`, `test/project-library.test.js:147`, `test/project-library.test.js:148`, `test/project-library.test.js:159`, `test/project-library.test.js:160`, `test/project-library.test.js:167`, `test/project-library.test.js:171`, `test/project-library.test.js:183`, `test/project-plugin.test.js:23`, `test/project-plugin.test.js:24`, `test/project-plugin.test.js:38`, `test/project-plugin.test.js:39`, `test/website-builder-integration.test.js:12`, `test/website-builder-integration.test.js:13`, `test/website-builder-integration.test.js:79` |
| `OCHA_PYTHON_BIN` | Application configuration | Yes | Yes | `scripts/maintain-two-bases.js:16`, `scripts/release-two-bases.js:101`, `src/runtime/consciousness-runtime.js:204`, `src/runtime/consciousness-runtime.js:205`, `test/consciousness-runtime.test.js:49`, `test/consciousness-runtime.test.js:53`, `test/consciousness-runtime.test.js:65`, `test/nadi-runtime.integration.test.js:25`, `test/nadi-runtime.integration.test.js:26` |
| `OCHA_RENTAL_API_HOST` | Application configuration | Yes | No | `src/rental/http-api.js:184` |
| `OCHA_RENTAL_API_PORT` | Application configuration | Yes | No | `src/rental/http-api.js:183` |
| `OCHA_RENTAL_API_TUNNEL` | Application configuration | Yes | No | `src/rental/http-api.js:190` |
| `OCHA_ROO_MASTER_KEY` | Secret / credential | Yes | Yes | `src/ai/user-vault.js:49`, `test/ai-memory-store.test.js:46`, `test/ai-memory-store.test.js:49`, `test/ai-memory-store.test.js:64`, `test/legacy-history-migration.test.js:12`, `test/user-vault.test.js:13`, `test/user-vault.test.js:112` |
| `OCHA_ROO_ROOT` | Application configuration | Yes | Yes | `src/ai/project-library.js:122`, `src/ai/user-vault.js:29`, `test/ai-memory-store.test.js:45`, `test/ai-memory-store.test.js:48`, `test/ai-memory-store.test.js:63`, `test/feature-requests.test.js:13`, `test/feature-requests.test.js:14`, `test/legacy-history-migration.test.js:11`, `test/project-library.test.js:168`, `test/project-library.test.js:172`, `test/project-library.test.js:178`, `test/project-library.test.js:184`, `test/tictactoe-engine.test.js:11`, `test/tictactoe-engine.test.js:15`, `test/user-vault.test.js:12`, `test/user-vault.test.js:24`, `test/user-vault.test.js:71`, `test/user-vault.test.js:92`, `test/user-vault.test.js:111` |
| `OPENAI_API_KEY` | Secret / credential | Yes | Yes | `src/ai/providers.js:74`, `src/ai/providers.js:107`, `src/core/config-disclosure.js:59`, `test/ai-checkpoint-recovery.test.js:13`, `test/ai-free-policy.test.js:14`, `test/ai-free-policy.test.js:21`, `test/ai-speed.test.js:13`, `test/owner-security.test.js:74`, `test/owner-security.test.js:76`, `test/owner-security.test.js:96`, `test/owner-security.test.js:97`, `test/website-builder-integration.test.js:15` |
| `PATH` | Host / OS environment | Yes | Yes | `src/acie/runtime/sandbox-runner.js:36`, `src/master/dispatcher.js:35`, `src/runtime/code-lab.js:421`, `src/runtime/code-lab.js:911`, `src/runtime/code-lab.js:1204`, `src/runtime/code-lab.js:1322`, `src/runtime/consciousness-runtime.js:58`, `test/bootstrap-agent.test.js:87`, `test/runtime-fallback.test.js:40`, `test/website-preview-gateway.test.js:22`, `test/website-preview-gateway.test.js:23`, `test/website-preview-gateway.test.js:221` |
| `PYTHONHOME` | Host / OS environment | Yes | No | `src/runtime/consciousness-runtime.js:58` |
| `PYTHONPATH` | Host / OS environment | Yes | No | `src/runtime/consciousness-runtime.js:59` |
| `QWEN_API_KEY` | Test only | No | Yes | `test/ai-speed.test.js:13` |
| `SSL_CERT_DIR` | Host / OS environment | Yes | No | `src/runtime/consciousness-runtime.js:58` |
| `SSL_CERT_FILE` | Host / OS environment | Yes | No | `src/runtime/consciousness-runtime.js:58` |
| `SYSTEMROOT` | Host / OS environment | Yes | No | `src/runtime/consciousness-runtime.js:58` |
| `TEMP` | Host / OS environment | Yes | No | `src/runtime/consciousness-runtime.js:58` |
| `TERM` | Host / OS environment | Yes | No | `src/core/logger.js:39`, `src/core/message-monitor.js:21` |
| `TMP` | Host / OS environment | Yes | No | `src/runtime/consciousness-runtime.js:58` |
| `TMPDIR` | Host / OS environment | Yes | No | `src/master/dispatcher.js:35`, `src/runtime/consciousness-runtime.js:58` |
| `USERPROFILE` | Host / OS environment | Yes | No | `src/runtime/consciousness-runtime.js:58` |
| `VIRTUAL_ENV` | Host / OS environment | Yes | No | `src/runtime/consciousness-runtime.js:58` |
| `WINDIR` | Host / OS environment | Yes | No | `src/runtime/consciousness-runtime.js:58` |

## Dynamic environment access

These expressions use a computed property name. Entries resolvable from a local literal, constant, literal array, or provider registry are included in the static table; unresolved expressions remain listed here for manual review.

| Scope | Location | Expression | Resolution |
|---|---|---|---|
| test | `test/ai-checkpoint-recovery.test.js:16` | `process.env[key]` | Not statically resolved |
| test | `test/ai-checkpoint-recovery.test.js:53` | `process.env[key]` | Not statically resolved |
| test | `test/ai-checkpoint-recovery.test.js:53` | `process.env[key]` | Not statically resolved |
| test | `test/ai-free-policy.test.js:46` | `process.env[key]` | Not statically resolved |
| test | `test/ai-free-policy.test.js:46` | `process.env[key]` | Not statically resolved |
| test | `test/ai-speed.test.js:16` | `process.env[key]` | Not statically resolved |
| test | `test/ai-speed.test.js:81` | `process.env[key]` | Not statically resolved |
| test | `test/ai-speed.test.js:81` | `process.env[key]` | Not statically resolved |
| test | `test/nadi-component.test.js:45` | `process.env[key]` | Not statically resolved |
| test | `test/nadi-component.test.js:45` | `process.env[key]` | Not statically resolved |
| test | `test/website-builder-integration.test.js:18` | `process.env[key]` | Not statically resolved |
| test | `test/website-builder-integration.test.js:82` | `process.env[key]` | Not statically resolved |
| test | `test/website-builder-integration.test.js:82` | `process.env[key]` | Not statically resolved |

## Shell installer environment overrides

These are shell-time overrides, not Node.js `dotenv` configuration. The scanner records direct `$NAME`, `${NAME}`, and default/assignment/alternate/error parameter-expansion forms.

| Name | Location | Usage |
|---|---|---|
| `ID` | `scripts/bootstrap/ensure-host.sh:61` | Shell installer / host tooling; not loaded from dotenv automatically |
| `ID_LIKE` | `scripts/bootstrap/ensure-host.sh:62` | Shell installer / host tooling; not loaded from dotenv automatically |
| `NEXORA_BOOTSTRAP_DRY_RUN` | `scripts/bootstrap/ensure-host.sh:10` | Shell installer / host tooling; not loaded from dotenv automatically |
| `OCHA_NODE_BIN` | `scripts/install-ai-model-catalog-timer.sh:15` | Shell installer / host tooling; not loaded from dotenv automatically |
| `OCHA_RUN_USER` | `scripts/install-ai-model-catalog-timer.sh:17` | Shell installer / host tooling; not loaded from dotenv automatically |
| `SUDO_USER` | `scripts/install-ai-model-catalog-timer.sh:17` | Shell installer / host tooling; not loaded from dotenv automatically |
| `SUDO_USER` | `scripts/uninstall-ai-model-catalog-timer.sh:11` | Shell installer / host tooling; not loaded from dotenv automatically |
| `TMPDIR` | `scripts/bootstrap/ensure-host.sh:207` | Shell installer / host tooling; not loaded from dotenv automatically |
| `USER` | `scripts/install-ai-model-catalog-timer.sh:12` | Shell installer / host tooling; not loaded from dotenv automatically |

## Whole-environment pass-through

The following code paths pass the inherited `process.env` object to another process or API. This scanner does not infer every key present on the host; review these call sites when changing child-process boundaries.

- `scripts/ac-git-setup.js:12` — process.env
- `scripts/ac-git-setup.js:41` — process.env
- `scripts/bootstrap/npm-deps.js:74` — process.env
- `scripts/install-private-runtime.js:77` — process.env
- `scripts/maintain-two-bases.js:26` — process.env
- `scripts/maintain-two-bases.js:77` — process.env
- `scripts/release-two-bases.js:47` — process.env
- `src/ai/model-catalog-worker-manager.js:37` — process.env
- `src/core/ac-auto-git-sync.js:11` — process.env
- `src/core/ac-auto-git-sync.js:103` — process.env
- `src/core/auto-git-sync.js:24` — process.env
- `src/core/auto-git-sync.js:116` — process.env
- `src/index.js:160` — process.env
- `src/index.js:226` — process.env
- `src/lib/youtube-service.js:62` — process.env
- `src/runtime/bootstrap-agent.js:88` — process.env
- `src/runtime/bootstrap-agent.js:136` — process.env
- `test/acie-runtime-audit.test.js:80` — process.env
- `test/ai-local-policy.test.js:91` — process.env
- `test/ai-model-catalog.test.js:154` — process.env
- `test/ai-response-repair-integration.test.js:42` — process.env
- `test/bootstrap-agent.test.js:23` — process.env
- `test/bootstrap-agent.test.js:52` — process.env
- `test/bootstrap-agent.test.js:87` — process.env
- `test/nadi-runtime.integration.test.js:78` — process.env
- `test/runtime-fallback.test.js:40` — process.env
- `test/website-preview-gateway.test.js:91` — process.env
- `test/website-preview-gateway.test.js:191` — process.env
- `test/youtube-config.test.js:35` — process.env

## Scanner integrity

- All scanned JavaScript files parsed successfully.

## Rules

- `Internal runtime marker`: assigned or consumed by Ocha during startup/handoff; do not set manually in `.env`.
- `Host / OS environment`: inherited from the host operating system or Node/npm; do not copy into `.env` unless deliberately overriding a host default.
- `Secret / credential`: keep the value only in ignored `.env` or the deployment secret manager. `.env.example` must contain empty placeholders only.
- `Test only`: referenced by tests but not by the production runtime; it is not added to `.env.example`.
- `Preserved source only`: found only in preserved contribution material; not considered an active runtime setting.
- New production keys not already curated in `.env.example` are added to its generated block as commented review items.
- `npm test` uses strict mode and fails when a production computed environment read cannot be resolved to a known key.
