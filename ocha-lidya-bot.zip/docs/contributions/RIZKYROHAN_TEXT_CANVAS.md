# Rizkyrohan — Text Canvas Generator (v1)

**Release review:** Ocha Lidya 1.10.49  
**ACIE capability:** `image-canvas.render.text`  
**Command draft:** `.textimage` (alias `.timg`)  
**Runtime status:** quarantined / not executable / not published in the public menu

## 1. Source preservation and integrity

The complete original contribution is preserved byte-for-byte in the operator-only ignored area at:

```text
.private/contributions/rizkyrohan-text-canvas-v1/
├── ACIE_RECEIPT.json
├── README.md
└── original/
    └── index.mjs
```

The `original/index.mjs` file is a byte-for-byte copy of Rizkyrohan's submitted source. Do not format, rename variables in, refactor, or patch this original file. Any production adapter must be maintained as a separate file and must not replace the archived source.

- Contributor: `Rizkyrohan`
- Contribution: `text-canvas-generator`
- Source size: `3460` bytes
- SHA-256: `30e451e96eedfa9c755b5f23f7825e19ea059749707cfd8b5878f72f7b4f4a43`
- License: `PENDING_INFORMATION`
- Execution authorization: `NOT_AUTHORIZED`
- Source execution during intake/tests: `false`

The automated test reads this exact private fixture instead of using a shortened imitation of the script. It checks the receipt's byte count and hash before performing static analysis, then verifies that intake preserves the same bytes in the private vault.

## 2. Original implementation inventory

The original implementation is retained with all its original names, values, operations, and error handling. These are the important source elements; this list documents them and does not replace the source file.

| Variable / element | Original value or behavior |
|---|---|
| `creator` | `"Rizkyrohan"`; used to calculate `ctx.globalAlpha` and JPEG quality |
| `source` | WhatsApp channel URL; its string length contributes to `minFontSize`; also appears in the catch-message classification |
| `FontDownload` | GitHub blob URL for `arialnarrow.ttf`; declared in the source, but not used to download the font at runtime |
| Canvas dependency | Dynamic ESM import of `@napi-rs/canvas` |
| `width`, `height` | `1594`, `3200` |
| `atasbawah`, `kanankiri` | `-650`, `-300`; vertical/horizontal text offsets |
| `zoom` | `1`; background scaling factor |
| `textZoom` | `1`; text scaling factor |
| `areaWidth`, `areaHeight` | `650`, `800`; text-fit area |
| `lineSpacing` | `1.0` |
| `boldMode`, `boldSize` | `'tebal'`, `1`; controls stroke-based bold appearance |
| `stretchY`, `stretchX` | `2`, `1`; text transform factors |
| Font registration | `GlobalFonts.registerFromPath('./Library/arialnarrow.ttf', 'Arial Narrow')` |
| Background | Remote image `IMG-20261110-WA0238.jpg`, loaded with `loadImage()` |
| `content` | Fixed text: `mark tidur, besok ban grup lagi` |
| `maxChars`, `maxWords` | `10`, `2`; line splitting constraints |
| `centerX`, `centerY` | Canvas center adjusted by `kanankiri` and `atasbawah` |
| `words`, `lines`, `line` | Whitespace tokenization and line accumulation, constrained by word count and character count |
| `extra` | Additional measured width when `boldMode === 'tebal'` |
| `maxFontSize`, `minFontSize` | `400`; and `Math.min(20, source.length * 4)` |
| Font-fit loop | Reduces font size by `2` until all lines fit both width and height constraints or the minimum threshold is reached |
| Text drawing | `#18362F` fill/stroke, rounded joins, centered alignment, middle baseline, alpha derived from `creator.length`, per-line save/translate/scale/stroke/fill/restore |
| Output | JPEG from `canvas.encode('jpeg', Math.min(100, 90 + creator.length))` |
| WhatsApp delivery | `conn.sendMessage(m.chat, { image: output, mimetype: 'image/jpeg' }, { quoted: m })` |
| Error handling | Converts the thrown value to a message; replies with the generic retry text when it matches `/creator|source/i`; otherwise replies with `Error: <message>` |

**Important behavior:** the source has no callable export and performs work at module top level. It expects the legacy ambient identifiers `conn` and `m`. Its text is hardcoded; no command argument or dynamic text input is implemented in v1.

## 3. Runtime prerequisites and unresolved assets

The source expects `@napi-rs/canvas`, but the dependency has no pinned version in the original contribution and is not added to the bot's production dependencies by this review. It also expects a local font at `./Library/arialnarrow.ttf`, while the background is loaded from a remote GitHub raw URL. The declared `FontDownload` constant does not itself download or register the font.

Neither font nor background asset is included in the contribution fixture. Their licensing/permission status remains pending. Do not bundle, mirror, or use them in a production feature until usage and redistribution permission are confirmed, and then snapshot them with hashes into an approved asset directory.

## 4. Safe ACIE intake on the VPS

Run from the Ocha Lidya repository root after installing the repository's dependencies. This performs static discovery and vault preservation; it does not execute the contributed script:

```bash
npm run acie:intake -- \
  --source .private/contributions/rizkyrohan-text-canvas-v1/original \
  --contributor-id rizkyrohan \
  --contributor-name Rizkyrohan \
  --name text-canvas-generator \
  --project-id ocha-lidya-bot \
  --attribution "Original implementation credited to Rizkyrohan; see .private/contributions/rizkyrohan-text-canvas-v1/ACIE_RECEIPT.json"
```

The ACIE vault destination is generated at runtime and will normally be:

```text
contributions/vault/rizkyrohan/text-canvas-generator/versions/v1/original/index.mjs
```

This path is created only after the intake command succeeds. It must not be assumed to exist merely because this release contains the archive fixture. The generated contribution ID is random; use `.acie contribution list` and `.acie contribution inspect <contribution-id>` to obtain it.

## 5. Activation gates

The `.textimage` / `.timg` command remains a hidden command draft. It is not a working command and must not be added to the public menu yet. Activation requires all of the following:

1. Written license/permission for the contributed source and both referenced assets.
2. Local, integrity-checked copies of the font and background in an approved asset store.
3. A separate adapter that preserves the original source bytes and provides an explicit, concurrency-safe `conn`/`m` bridge; do not import the original top-level module directly into the bot process.
4. A pinned `@napi-rs/canvas` version in an isolated runtime, with the required runtime library verified.
5. Protocol, sandbox, media-output, quoted-message, and error-path tests on the target VPS.
6. Owner authorization recorded through ACIE governance.

Until these gates pass, ACIE keeps the provider quarantined, records the command as `draft-pending-validation`, and does not expose it in the user menu. This is intentional; the revision preserves the contribution without silently changing its logic or claiming it is operational.
