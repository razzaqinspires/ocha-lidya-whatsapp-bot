# Lunara Pro — Contribution Review

## Intake identity

| Field | Value |
|---|---|
| Contribution ID | `OCHA-CONTRIB-LUNARA-PRO-001` |
| Contribution name | Lunara Pro HTTP client / scraper CLI |
| Contributor | Not supplied in the conversation |
| Received | 2026-11-26 (Asia/Jakarta; chat submission) |
| Source name | `lunara_scraper.js` (suggested by the CLI usage text; original filename not attached) |
| Source transport | Inline JavaScript pasted into chat |
| Original byte preservation | **Pending** — no original source file was attached, so byte-identical preservation cannot be asserted |
| Original SHA-256 | **Unavailable** — must be computed from the original attached file |
| License | Not supplied; integration/republication permission is unverified |
| External service | `https://lunara.softbotz.my.id` |
| Package baseline reviewed | `ocha-lidya-whatsapp-bot@1.10.55` |

## Status

- `DISCOVERED` — the pasted source exposes a Lunara HTTP client and CLI.
- `ANALYZED` — capabilities, dependencies, runtime compatibility and security risks reviewed statically.
- `ADAPTER_REQUIRED` — the source is CommonJS while Ocha is ESM; a separately reviewed ESM adapter is required.
- `PRESERVED` — **not claimed**; an original file attachment is required for immutable storage and a trustworthy SHA-256.
- `TESTED` — **not claimed**; the contribution itself was not executed and no calls were made to the external service.
- `APPROVED`, `REGISTERED`, `ACTIVE` — **not reached**.

## Discovered capabilities

| Capability ID (proposed; not registered) | Input | Expected output | Side effects |
|---|---|---|---|
| `storage.lunara.file.upload` | Local path or Buffer/Uint8Array, filename and MIME type | File ID, file URL, raw URL, expiry metadata | Sends file bytes to the external Lunara service |
| `storage.lunara.text.publish` | Text/code string | Paste ID, URL, language, size, line count, expiry metadata | Sends text to the external Lunara service |
| `storage.lunara.raw.fetch` | File/paste ID or Lunara URL | Content type and raw bytes | Downloads remote content into process memory |
| `storage.lunara.file.download` | ID/URL and local destination path | Saved absolute path | Writes downloaded bytes to local disk |
| `storage.lunara.config.inspect` | No input | Server configuration/retention JSON | Reads the remote `/api/config` endpoint; possible configuration disclosure |

These are capabilities described by the supplied client, not independently verified server contracts. The service response fields (`id`, `url`, `file_url`, `language`, `size`, `lines`, `expires_at`, `permanent`, `upload_id`) must be validated against the real API before activation.

## Runtime and dependencies

- Language: JavaScript.
- Module format in supplied source: CommonJS (`require`, `module.exports`, `require.main`).
- Ocha module system: ESM (`package.json` has `"type": "module"`). The pasted file cannot be added unchanged as `.js` and imported as an ordinary ESM module.
- Runtime APIs: `fetch`, `FormData`, `Blob`, `AbortSignal.timeout`, `Buffer`, `URL`.
- Third-party npm dependencies in the pasted client: none; filesystem and path access use Node built-ins.
- Ocha engine baseline: Node.js `>=20.18.0`; run compatibility tests against that baseline and the current production Node release before deployment.

## Static security and correctness findings

| Severity | Finding | Impact / required mitigation |
|---|---|---|
| Critical | `options.baseUrl` is unrestricted and may use arbitrary schemes/hosts | A caller can turn the client into an SSRF primitive or send private uploads to another host. Enforce HTTPS and an explicit host allowlist; do not take base URLs from WhatsApp users. |
| High | `fetch` uses the default redirect behavior | Redirects can move requests away from the intended host. Reject redirects or validate every redirect destination against the same allowlist. |
| High | `getRaw()` buffers the complete response with `arrayBuffer()` and has no client-side byte ceiling | A hostile/incorrect response can exhaust process memory. Enforce `Content-Length` when present and a streaming byte limit while reading. |
| High | File upload size is not checked locally | The 100 MB figure exists in comments/help text only. Check file stat/Buffer byte length before creating the request; prefer bounded streaming for disk paths. |
| High | Text upload size is not checked locally | The 2 MB figure exists in comments/help text only. Enforce UTF-8 byte length before upload. |
| High | The `download()` method accepts an arbitrary destination path and synchronously overwrites it | Keep this API restricted to trusted callers; validate destination policy, use async/atomic writes, safe file modes and explicit overwrite behavior. Never expose raw local paths to public WhatsApp command arguments. |
| Medium | `uploadToLunara()` treats a string as text only when it contains a newline and is not a path | One-line text such as `hello` is interpreted as a local path and fails. Use an explicit upload mode or a dedicated `uploadText()` call. |
| Medium | `extractId()` does not validate the extracted identifier | Validate an explicit ID character set and length; reject malformed URLs, path traversal and unsupported hosts. |
| Medium | `getConfig()` trusts any JSON response shape | Validate content type, response size and a documented schema; keep this operation owner-only and redact sensitive values. |
| Medium | Upload result fields and URLs are trusted without schema/host checks | Validate required fields and ensure returned URLs are HTTPS and belong to the approved Lunara origin before returning them to users. |
| Medium | Synchronous `readFileSync` / `writeFileSync` block the Node event loop | Replace with async filesystem operations; avoid unbounded whole-file copies and test memory/latency under load. |
| Medium | User-supplied filename and MIME type are forwarded without robust sanitation | Strip path components/control characters, bound lengths, and normalize MIME type before multipart serialization. |
| Medium | No explicit idempotency key or retry policy exists | Do not add blind retries to upload operations; only retry after an idempotency contract is documented. |
| Medium | Retention and `permanent` values come from an unverified service response | Show expiry/retention to users before sharing; do not promise durability until the server contract and retention policy are verified. |
| Low | Browser-like User-Agent, Origin and Referer are hard-coded | Confirm whether these headers are required by the service. Avoid relying on browser impersonation as an API contract. |

## Ocha compatibility and existing capabilities

- Ocha baseline is ESM. The supplied code needs an adapter/port; it must not be dropped into `src/` as an unchanged `.js` file.
- Node 20.18 provides the required web APIs used by the snippet; verify the exact minimum with automated tests rather than inferring it only from comments.
- Ocha already has a native WhatsApp media download path in `m.download()` and existing local media/storage flows. A future WhatsApp adapter should pass only explicitly selected, already-downloaded message buffers to the provider; it must not allow public users to nominate arbitrary server filesystem paths.
- Ocha currently has 46 loaded plugins. Static collision audit found no collisions and no current command/alias named `lunara`, `paste`, `pastebin`, `upload`, `filehost` or `raw`. This is a snapshot, not permanent reservation.
- Candidate user surface, only after approval: owner-only `.lunara status|config|text|upload|get`. Public uploads should remain disabled until consent, quota, abuse controls and retention messaging are implemented.
- This is a file-host/paste capability, not an AI inference provider. Do not register it in the AI model-provider registry. If approved, give it a separate storage-provider/capability contract and a health/contract check.
- No npm dependency is required by the pasted implementation. No dependency was added.

## External verification

The supplied endpoint was not verified against a retrievable public API specification in this review. Attempts to open the homepage and `/api/config` through the available web reader did not return the API schema. This does **not** prove that the service is offline; it means server behavior, upload limits, response fields, retention behavior, authentication, rate limits and redirects remain unverified. No file, text, or test payload was sent to the service.

## Integration decision

**Decision: hold before activation.** Do not copy the snippet into the runtime, add a public command, register a provider, or send user data to Lunara yet.

Required intake/approval gates:

1. Attach the exact original `.js`/`.cjs` source file so its bytes can be preserved and SHA-256 recorded.
2. Provide contributor attribution and the license or written permission to modify and integrate the source.
3. Provide official API documentation or a safe test account/environment with verified request/response schemas, retention policy, size limits, auth/rate-limit behavior and redirect policy.
4. Build a separate ESM adapter around the documented contract, with HTTPS host allowlisting, response and upload size limits, safe filename/MIME handling, bounded streaming, strict URL/ID validation and no user-controlled local paths.
5. Add mocked unit/contract tests and a controlled, non-sensitive live health test. Keep the provider disabled by default until both pass.
6. Run command collision, `.env` inventory, documentation, security publication and full Ocha regression checks before any release.

## Test and activation record

- Contribution source executed: No.
- External HTTP requests made to Lunara: No.
- Mock contract tests: Not yet created.
- Ocha plugin collision snapshot: 46 plugins loaded, 0 collisions.
- Proposed commands occupied at review time: none among `lunara`, `paste`, `pastebin`, `upload`, `filehost`, `raw`.
- Runtime registration: none.
- Activation: disabled / not implemented.

## Artificial Consciousness maintenance boundary

The Lunara contribution review itself did not require changes to NADI, heartbeat timing, interoception, affect appraisal, neuromodulation, deliberation, dreaming, self-model or memory. Its AC test results (`selftest.py` 4/4 and `test_prime.py` 9/9) are historical results from that review snapshot, not the current AC baseline. The subsequent paired maintenance cycle advanced the independent AC component to v2.1.1; see `docs/NADI_MAINTENANCE_REPORT_2.1.1.md` and the separate AC package/report. Neither test set is a live VPS or WhatsApp test.

## Ocha baseline checks run during this review

These checks validate the current Ocha workspace and documentation; they do not test the Lunara service or contribution client.

| Check | Result |
|---|---|
| `node --test` | 406 tests discovered; 405 passed, 0 failed, 1 skipped |
| Skipped test | Private-runtime live import test requires the unavailable Baileys peer dependency |
| `npm run check` | Passed; 294 JavaScript files syntax-checked and environment inventory remained synchronized |
| Environment inventory | 313 JS + 3 shell files; 58 unique environment names |
| `npm run docs:check` | Passed; 77 Markdown files and local links validated |
| `npm run security:publication` | Passed; 418 files inspected, 392 public and 26 private excluded; no private fingerprint/credential findings |
| `npm run private-runtime:verify` | Passed; four immutable private-runtime source modules verified |
| ACC `selftest.py` | 4/4 passed |
| ACC `test_prime.py` | 9/9 passed |

`npm test` as an npm lifecycle command was not run in this review. The direct `node --test` suite was run instead; it does not execute the `pretest` dependency-bootstrap hook. No source implementation was changed, and no live WhatsApp or Lunara service test was performed.
