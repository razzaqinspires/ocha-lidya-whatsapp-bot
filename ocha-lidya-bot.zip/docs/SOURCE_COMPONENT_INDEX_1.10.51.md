# Source Component and Function Index — Ocha Lidya v1.10.51

> This index maps verified source entry points and their most important functions/classes. It is not a generated API reference for every private helper. Paths were checked against the supplied archive; function names below were read from declarations in those files. No line numbers are recorded because generated line references become stale after edits.

## Runtime and core

| Component ID | Responsibility | Source / symbols | Related components | Tests / status |
|---|---|---|---|---|
| `BOOT-001` | Process bootstrap, socket lifecycle, reconnect and shutdown | `src/index.js` — `start`, `shutdownRuntime`, `requestControlledRestart`, `scheduleReconnect` | config, database, ACIE, provider keys, NADI, plugin loader, dispatcher | `test/runtime-*`, `test/whatsapp-*`; source present, full host runtime not exercised |
| `PLUGIN-001` | Discover/import plugin modules, preserve prior valid registry snapshot, load ACIE virtual plugin descriptors | `src/core/plugin-loader.js` — `loadPlugins`, `refreshGeneratedCommandPlugins`, `listPlugins`, `listPluginEntries`, `getPlugin`, `watchSourceFiles` | dispatcher, ACIE command engine, file watcher | `test/plugin-loader*`, `test/hot-reload-batch.test.js`; source and focused tests present |
| `DISPATCH-001` | Route incoming message, prefix, reply-session and command execution | `src/core/dispatcher.js` — `dispatch` | plugin execution, identity, reply sessions, master console, AI engine | dispatch/permissions tests; source present |
| `EXEC-001` | Permission/rental/quota/cooldown gates before plugin execution | `src/core/plugin-execution.js` — `resolvePluginExecutionCommand`, `executeRegisteredPlugin` | identity, permissions, tenant policy, governor | owner/rental/tenant tests; source present |
| `DB-001` | JSONL record journal, atomic snapshots, archive rotation/search and integrity | `src/core/database.js` — `initializeDatabase`, `appendRecord`, `getRecords`, `getLatestConfigRecord`, `searchArchives`, `databaseHealth` | config, AI providers, User Vault, audit/telemetry | `test/database.test.js`, `test/contact-db.test.js`; source present, live records not inspected |
| `SER-001` | WhatsApp message serialization, quote/context/media normalization and socket extensions | `src/lib/serializ_simple.js` public facade; private implementation is external package `src/lib/serializ_simple.js` — `serialize`, `extendSocket`, `trackSentMessageId`, `setOutgoingMessageObserver` | Baileys, private runtime loader, host bridge, dispatcher, media helpers, Native Flow registry | `test/private-runtime.test.js`, serializer/native-flow tests; public facade `ADAPTER_READY`, private source `PRESERVED`, activation not verified |
| `MASTER-001` | Owner developer runners and workload checks | `src/master/dispatcher.js` — `isMasterSyntax`, `getRunnerForToken`, `executeMasterCommand`, `runJs` | config security, database, workload tracker | `test/master-*`; owner-only opt-in; JS `vm` is not a sandbox |

## Public / private runtime boundary

| Component ID | Responsibility | Source / symbols | Related components | Tests / status |
|---|---|---|---|---|
| `PRIV-LOADER` | Resolve optional `@razzaqventures/ocha-private-runtime`, validate its contract and maintain public fallback status | `src/private-runtime/loader.js` — `loadPrivateRuntime`, `getPrivateRuntimeStatus`, `isPrivateRuntimeRequired` | package resolution, adapters, plugin loader | `test/private-runtime.test.js`; public fallback `TESTED`, private host activation not verified |
| `PRIV-SERIAL` | Provide bounded public serializer when private package is absent | `src/private-runtime/public-serializer.js` — `serializePublicMessage`, `createPublicSerializer`, `unwrapMessage` | Baileys, host message-text/contact/reply services | `test/private-runtime.test.js`; `ADAPTER_READY` |
| `PRIV-FACADE` | Preserve stable import surfaces for helpers, fake replies and serializer | `src/lib/helpers.js`, `src/lib/freply.js`, `src/lib/serializ_simple.js`; `src/private-runtime/adapter-state.js` | plugin modules and bootstrap | `test/esm-imports.test.js`, `test/private-runtime.test.js`; public facade `TESTED` |
| `PRIV-BRIDGE` | Restrict private package access to explicit public host services | External package `host-bridge.js`; host wrappers `src/core/*`, `src/lib/*`, `src/plugins/owner/message-test-catalog.js` | logger, contacts, reply sessions, message parser, native-flow policy | private package syntax check and integrity test; allowlist `ANALYZED`, live imports require target-host validation |
| `PRIV-PLUGIN` | Offer the private Message Test Lab to the existing plugin registry | External package `src/plugins/owner/message-lab.js`; `src/core/plugin-loader.js` — `mergePrivateRuntimePlugins` | command registry, owner/private policy, dispatcher | `test/private-runtime.test.js`; plugin `PRESERVED`, package activation not verified |
| `PRIV-INSTALL` | Validate private package metadata and source hashes before operator install | `scripts/install-private-runtime.js`; `scripts/private-runtime-status.js` | Node/npm, private package manifest | syntax tested; operator install not run in audit environment |

## AI, context and provider routing

| Component ID | Responsibility | Source / symbols | Related components | Tests / status |
|---|---|---|---|---|
| `AI-001` | AI turn routing, context, memory, provider execution, delivery and persistence | `src/ai/engine.js` — `isAITrigger`, `executeWithFallback`, `completeTruncatedResponse`, `repairGenericNonAnswer`, `answerMessage`, `resumePendingAI`, `getAIStatus` | providers, User Vault, profile, reply chain, NADI prompt | AI engine/response quality tests; source present |
| `AIP-001` | Multi-provider credentials, key rotation, error classes, model metadata, fallback | `src/ai/providers.js` — `initializeProviderKeys`, `classifyProviderFailure`, `listProviderModels`, `getProviderInventory`, `generateWithProvider`, `generateWithFallback` | AI engine, config, JSONL database | provider tests; no live credential health inferred |
| `VAULT-001` | Per-user encrypted conversation storage and private recall | `src/ai/user-vault.js`, `src/ai/memory-store.js` | AI engine, profile and project memory | User Vault tests; private runtime data not inspected |
| `QUALITY-001` | Detect known generic non-answers; one bounded correction and truthful fallback | `src/ai/response-quality.js` — `isSubstantiveUserTurn`, `isGenericNonAnswerResponse`, `buildNonAnswerFallback` | AI engine | response-quality tests; heuristic, not semantic fact-checking |

## ACIE — Contribution intake and orchestration

| Component ID | Responsibility | Source / symbols | Related components | Tests / status |
|---|---|---|---|---|
| `ACIE-001` | ACIE lifecycle and storage initialization | `src/acie/index.js` — `initializeACIE` | DB, plugin loader, private contribution vault | ACIE foundation tests; default execution deny |
| `ACIE-INTAKE` | Preserve contribution, build manifest/provenance, static analysis and drafts | `src/acie/orchestration/contribution-intake.js` — `runContributionIntake` | static analysis, capability discovery, governance, command generation | contribution intake tests; submitted source is not executed |
| `ACIE-ANALYSIS` | Language/module/dependency/function/security discovery | `src/acie/intelligence/static-analysis.js` — `analyzeContribution`; `language-discovery.js` — `identifyLanguage`, `identifyRuntime`, `detectModuleSystem`; `capability-discovery.js` — `discoverCapabilities` | interface discovery, policy, manifest | ACIE static tests; discoveries are candidates/unverified |
| `ACIE-GOV` | Evaluate provenance/license/review/owner approval and activation stages | `src/acie/governance/governance-manager.js` — `evaluateContributionGovernance`; `provider-approval.js` — `reviewProviderStage`, `testProviderAdapter` | provider registry, audit log | governance/protocol tests; default deny |
| `ACIE-PROVIDER` | Persist contribution/provider/capability state and health | `src/acie/registry/provider-registry.js` — `registerContribution`, `listProviders`, `listCapabilities`, `getProvider`, `setProviderEnabled`, `recordProviderExecution` | provider router, sandbox | provider-registry tests; runtime registry absent in ZIP |
| `ACIE-ROUTE` | Select active provider; bounded idempotent retry/fallback | `src/acie/routing/provider-router.js` — `routeProvider`; `error-classifier.js` — `classifyExecutionError` | sandbox runner, response normalizer | router tests; runtime not probed on VPS |
| `ACIE-SANDBOX` | Execute only under a pinned container and fail-closed isolation | `src/acie/runtime/runtime-manager.js` — `assertSandboxExecutionAllowed`; `sandbox-runner.js` — `buildSandboxArgs`, `runSandboxProcess`, `executeProviderInSandbox` | runtime configuration, adapter protocol | sandbox tests; Docker/Podman unavailable in audit container |
| `ACIE-CMD` | Draft and load generated virtual plugin descriptors | `src/acie/command-engine/command-generation.js`, `runtime-commands.js` — `loadGeneratedCommandPlugins` | existing plugin loader and dispatcher | command engine tests; no dynamic command activated by archive review |

## NADI external component boundary

| Component ID | Responsibility | Source / symbols | Related components | Tests / status |
|---|---|---|---|---|
| `NADI-LOAD` | Fetch, validate and atomically install external component archive | `src/runtime/nadi-component.js` — `parseGitHubRepository`, `resolveNadiComponent` | pinned Git ref, external cache, Python runtime | `test/nadi-component.test.js`; pinned NADI 2.1.0 SHA |
| `NADI-CLIENT` | Launch/monitor external sidecar, HTTP requests, heartbeat, shutdown | `src/runtime/consciousness-runtime.js` — `startConsciousnessRuntime`, `getConsciousnessStatus`, `tickConsciousnessNow`, `readConsciousnessStatus`, `consolidateConsciousnessMemory`, `verifyConsciousnessMemory`, `setConsciousnessEnabled`, `stopConsciousnessRuntime` | NADI `/v1/*` loopback API, Ocha lifecycle | `test/consciousness-runtime.test.js`; optional/degraded mode |
| `KERNEL-TELEM` | Aggregate counts/latencies without message content or sender identifiers | `src/runtime/kernel-telemetry.js` — `initializeKernelTelemetry`, `recordIncomingMessage`, `recordBotOutputMessage`, `beginAIRequest`, `finishAIRequest`, `getKernelTelemetrySnapshot` | public `.kernel` dashboard | `test/kernel-telemetry.test.js`; aggregate telemetry |

## Related technical references

- `docs/PRIVATE_RUNTIME_EXTRACTION.md` — private package layout, runtime modes, host bridge, install/rollback and Prettier boundaries

- `docs/ACIE_ARCHITECTURE.md`, `docs/ACIE_PART1_AUDIT.md`, `docs/ACIE_PART2_RUNTIME_ISOLATION.md`, `docs/ACIE_PART3_COMMAND_INTEGRATION.md`
- `docs/NADI_RUNTIME.md`, `docs/KERNEL_DASHBOARD.md`
- `docs/AI_ENGINE.md`, `docs/FALLBACK_ENGINE.md`, `docs/DATABASE_DESIGN.md`, `docs/NATIVE_FLOW_SERIALIZER.md`
- `docs/COMMAND_REGISTRY_AUDIT_1.10.51.md`, `docs/PROVIDER_REGISTRY_AUDIT_1.10.51.md`
- Original serializer/helper modules are preserved in the external private package and intentionally absent from this public tree. Public facades are not full-feature parity implementations; do not copy private originals into public paths.
