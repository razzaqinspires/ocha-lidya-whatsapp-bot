# Static Command Registry Audit — Ocha Lidya v1.10.51

> Generated from the exported plugin descriptors in `src/plugins/**/*.js` in the supplied v1.10.51 archive. This is a static source inventory, not a live runtime snapshot. A descriptor can still be unavailable because of import errors, runtime policy, tenant policy, or dynamic ACIE gates.

**Result after private-runtime extraction:** 46 canonical public plugin commands, 87 declared aliases, 133 normalized identifiers, and zero static canonical/alias collisions. The private `.test` command and its two aliases are not in the public source registry. One additional plugin-directory file (`src/plugins/owner/message-test-catalog.js`) supplies test catalogue data but does not export a command plugin.

| Canonical | Aliases | Category | Declared ownerOnly | Declared privateOnly | Declared groupOnly | Menu | Usage | Source |
|---|---|---|---:|---:|---:|---|---|---|
| `about` | `botinfo` | general | not declared | not declared | not declared | default | `not declared` | `src/plugins/general/about.js` |
| `groupadmin` | `gadmin`, `grupadmin` | general | not declared | not declared | not declared | default | `[info\` |aturan [teks]\|aturan hapus\|welcome on\|off [pesan]\|poll <pertanyaan> \| <opsi 1> \| <opsi 2> \| ...\|announce <pesan>] | `src/plugins/general/groupadmin.js` |
| `groupinfo` | `gcinfo`, `grouplist` | general | not declared | not declared | not declared | default | `[group-id]` | `src/plugins/general/groupinfo.js` |
| `kernel` | `kernelstatus`, `nadiweb` | general | not declared | not declared | not declared | default | `.kernel` | `src/plugins/general/kernel.js` |
| `memori` | `memory`, `ingatan`, `arsipchat` | general | not declared | not declared | not declared | default | `[status\` |fakta [halaman]\|cari <kata kunci>\|terbaru\|ekspor\|hapus-fakta <frasa>] | `src/plugins/general/memori.js` |
| `menu` | `help`, `commands` | general | not declared | not declared | not declared | default | `[kategori] [halaman]` | `src/plugins/general/menu.js` |
| `owner` | `creator` | general | not declared | not declared | not declared | default | `not declared` | `src/plugins/general/owner.js` |
| `ping` | `speed`, `latency` | general | not declared | not declared | not declared | default | `not declared` | `src/plugins/general/ping.js` |
| `profile` | `me`, `level`, `xp` | general | not declared | not declared | not declared | default | `not declared` | `src/plugins/general/profile.js` |
| `project` | `projects`, `repo`, `repository` | developer | not declared | not declared | not declared | default | `<list\` |status\|use\|history\|zip\|export> [value] | `src/plugins/general/project.js` |
| `run` | `execute`, `previewcode` | developer | not declared | not declared | not declared | default | `<python\` |node\|html> <code> | `src/plugins/general/run.js` |
| `runtime` | `system`, `sysinfo` | developer | not declared | not declared | not declared | default | `not declared` | `src/plugins/general/runtime.js` |
| `sewa` | `rent`, `paketsewa` | general | not declared | not declared | not declared | default | `[bandingkan\` |estimasi <anggota>\|faq\|rating\|testimoni\|ulasan <1-5> [komentar]\|masukan <pesan>\|konsultasi <pesan>\|status\|pesanan\|invoice [id]\|plan\|upgrade\|perpanjang\|pay\|paid\|bukti\|cancel] | `src/plugins/general/sewa.js` |
| `sewaapi` | `dashboardkey`, `webkey` | general | not declared | not declared | not declared | default | `[buat\` |list\|revoke] [rental\|profile\|id] | `src/plugins/general/sewaapi.js` |
| `website` | `buatwebsite`, `webprofile` | general | not declared | not declared | not declared | default | `[templates\` |create\|list\|publish\|editor\|edit\|post\|share\|verify\|paid\|bukti\|status\|guide] | `src/plugins/general/website.js` |
| `yts` | `ytsearch`, `ytmp3`, `ytmp4`, `ytm`, `ytmusic`, `ytplay` | general | not declared | not declared | not declared | default | `.yts <query> \` | .ytmp3 <url> \| .ytmp4 <url> [resolusi] \| .ytm <judul lagu> | `src/plugins/general/youtube.js` |
| `acie` | `contribengine` | owner | `true` | `true` | not declared | default | `.acie [status\` |contribution\|provider\|routing\|commands\|workers\|integrity\|security\|audit] | `src/plugins/owner/acie.js` |
| `aimodels` | `modelcatalog`, `modelcheck` | owner | `true` | not declared | not declared | default | `[status\` |refresh\|free\|all] | `src/plugins/owner/aimodels.js` |
| `aiset` | `aiconfig` | owner | `true` | not declared | not declared | default | `<setting> [value]` | `src/plugins/owner/aiset.js` |
| `aistatus` | `aihealth` | owner | `true` | not declared | not declared | default | `not declared` | `src/plugins/owner/aistatus.js` |
| `apikey` | `keys`, `keymanager` | owner | `true` | not declared | not declared | default | `<add\` |delete\|list\|get> <provider> [value] | `src/plugins/owner/apikey.js` |
| `buttons` | `buttonmode`, `uibuttons`, `button`, `fullbutton`, `commandbutton` | owner | `true` | `true` | not declared | default | `full <all\` |off\|status\|audit\|exclude add\|remove\|list> \| <on\|off\|status> | `src/plugins/owner/buttons.js` |
| `commandaudit` | `aliasaudit`, `commandconflicts` | owner | `true` | `true` | not declared | default | `[scan]` | `src/plugins/owner/commandaudit.js` |
| `config` | `configuration`, `settings` | owner | `true` | `true` | not declared | default | `[show]` | `src/plugins/owner/config.js` |
| `createcmd` | `makecmd`, `commandcreate` | owner | `true` | `true` | not declared | default | `<instruction\` |quoted-code> \| apply <draft-id> \| list | `src/plugins/owner/createcmd.js` |
| `dbsearch` | `archivefind` | owner | `true` | not declared | not declared | default | `<query>` | `src/plugins/owner/dbsearch.js` |
| `dbstatus` | `database`, `dbhealth` | owner | `true` | not declared | not declared | default | `not declared` | `src/plugins/owner/dbstatus.js` |
| `features` | `featurerequests`, `fiturreq` | owner | `true` | `true` | not declared | false | `[list\` |all\|show <request-id>\|progress <id>\|complete <id>\|cancel <id>]  | `src/plugins/owner/features.js` |
| `guard` | `commandguard`, `antispam` | owner | `true` | `true` | not declared | default | `<cooldown\` |antispam\|status> [on\|off\|user] | `src/plugins/owner/guard.js` |
| `jid` | `jidinfo`, `liddebug` | developer | `true` | not declared | not declared | default | `[message-context]` | `src/plugins/owner/jid.js` |
| `joingc` | `joingroup`, `join-group` | owner | `true` | `true` | not declared | default | `<invite-url>` | `src/plugins/owner/joingc.js` |
| `master` | `masterconfig` | owner | `true` | `false` | not declared | default | `[status\` |eval\|cli\|python\|golang\|warning\|review\|group] [on\|off\|true\|false\|compact\|detailed\|status] | `src/plugins/owner/master.js` |
| `mute` | `groupmute` | owner | `true` | not declared | not declared | default | `<on\` |off\|status> [all\|group-id] | `src/plugins/owner/mute.js` |
| `nadi` | `heartbeat`, `selfstate` | owner | `true` | `true` | not declared | default | `.nadi <status\` |on\|off\|pulse\|sleep\|verify> | `src/plugins/owner/nadi.js` |
| `nexora` | `capability`, `aitools` | owner | `true` | `true` | not declared | default | `[status\` |all\|code\|tunnel\|workers] [value] | `src/plugins/owner/nexora.js` |
| `plugins` | `pluginlist` | owner | `true` | not declared | not declared | default | `[reload]` | `src/plugins/owner/plugins.js` |
| `setprefix` | `prefix` | owner | `true` | not declared | not declared | default | `<mode\` |single\|add\|remove> [value] | `src/plugins/owner/prefix.js` |
| `react` | `autoreact`, `reactions` | owner | `true` | `true` | not declared | default | `[menu\` |on\|off\|status] | `src/plugins/owner/reactions.js` |
| `reload` | `reloadplugins` | owner | `true` | not declared | not declared | default | `not declared` | `src/plugins/owner/reload.js` |
| `rentals` | `rentaladmin`, `sewaadmin` | owner | `true` | `true` | not declared | default | `<status\` |list\|pending\|usage\|audit\|show\|approve\|reject\|suspend\|activate\|extend\|setprice\|setquota\|setmembers\|plans\|support\|reply\|close> | `src/plugins/owner/rentals.js` |
| `setbotname` | `botname` | owner | `true` | not declared | not declared | default | `<name>` | `src/plugins/owner/setbotname.js` |
| `setmenu` | `menuset`, `menuconfig` | owner | `true` | `true` | not declared | default | `<descriptions\` |pages\|limit\|status> [on\|off\|number] | `src/plugins/owner/setmenu.js` |
| `setmode` | `mode` | owner | `true` | not declared | not declared | default | `<public\` |self> | `src/plugins/owner/setmode.js` |
| `webverify` | `websiteverify` | owner | `true` | `true` | not declared | default | `[list\` |approve <invoice>\|reject <invoice> <alasan>] | `src/plugins/owner/webverify.js` |
| `ytconfig` | `youtubeconfig` | owner | `true` | `true` | not declared | default | `[status\` |binary\|ffmpeg\|maxsize\|maxduration\|results\|reset] [value] | `src/plugins/owner/ytconfig.js` |
| `tictactoe` | `ttt`, `xo` | games | `false` | `true` | `false` | default | `.ttt mulai [x\` |o] \| .ttt <1-9> \| .ttt status \| .ttt menyerah \| .ttt ulang | `src/plugins/tictactoe.js` |

## Interpretation and limits

- A blank/undeclared permission property does **not** mean public access. The dispatcher, `src/core/plugin-execution.js`, identity checks, command-specific handler logic, chat scope, rental tenant policy, cooldown and anti-spam gates remain authoritative.
- `menu: false` hides a command from the user-facing `.menu` inventory; it does not by itself mean the plugin is unloaded. In this snapshot `.features` is explicitly hidden.
- Aliases resolve through the same plugin registry as canonical names. Runtime menu generation suppresses alias collisions in favor of canonical names, but the source collision check above found none.
- ACIE-generated commands are dynamic. The ZIP does not include the runtime `generated-commands/index.json` and provider/command runtime registries, so no generated command is counted as active or included in this static inventory.
- Prefix is configurable. The source menu renderer uses the configured prefix and canonical registry; do not hard-code `.` as the only prefix.

## Non-plugin Master Console syntax

`src/master/dispatcher.js` separately recognizes `>>>`, `>>`, `=>`, `>`, and `$`. Both `>` and `=>` map to JavaScript eval; `$` maps to CLI shell; `>>` maps to Python; `>>>` maps to Go. These are not plugin aliases. Runtime flags are independently controlled, and the parser/dispatcher additionally requires a verified owner. JavaScript `vm` is explicitly not a security boundary; these runners must remain owner-only and opt-in.

## Runtime verification still required

Run the owner-only command audit (`.commandaudit scan`) on the actual live process after plugins and eligible ACIE virtual plugins load. That audit sees the runtime registry, unlike this archive-only source scan. Confirm private/group policy, permission checks, and menu visibility on the target WhatsApp account before calling the registry operational.


## Private runtime command boundary

`.test` (`testmsg`, `messagetest`) is supplied only by `@razzaqventures/ocha-private-runtime`. It is not counted among the 46 public plugin descriptors and does not appear in public-compatible mode. The private loader accepts it only when the package passes the serializer/helper/fake-reply contract, the plugin declares both `ownerOnly: true` and `privateOnly: true`, and its canonical name and aliases do not collide with the public or ACIE virtual registry. The live registry must still be checked with `.commandaudit scan` after package activation.
