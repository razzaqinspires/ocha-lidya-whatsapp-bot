# Source Component Index — Ocha v1.10.57 dual-repository auto-push

This additive index identifies the components changed or revalidated for the two-lane Git publication architecture. It does not replace earlier full source indexes or claim that a remote push has already occurred.

| Component ID | Component | Source location | Responsibility / contract | Tests | Status |
|---|---|---|---|---|---|
| `AUTO-PUSH-CONFIG` | Independent target configuration | `src/core/auto-push-config.js` | Persistent fixed-target enable flags under `.private/automation/auto-push.json`; credentials are never serialized; corrupt config is quarantined and both targets fail closed | `test/auto-push-config.test.js` | TESTED; local config behavior |
| `AUTO-PUSH-RUNTIME` | Two-lane lifecycle manager | `src/core/auto-push-runtime.js` | Starts/stops/flushes Ocha and AC publication services and keeps enable state independent | `test/auto-push-config.test.js`, source lifecycle audit | INTEGRATED; live remote not tested |
| `OCHA-GIT-SYNC` | Existing Ocha publisher | `src/core/auto-git-sync.js` | Retains legacy root watcher, GITHUB_PAT, Ocha branch/remote validation and publication checks; rejects any `.private/` path still tracked by Ocha index | `test/release-policy.test.js`, `test/watch-policy.test.js` | TESTED; GitHub push not executed |
| `AC-GIT-POLICY` | AC nested repository policy | `src/core/ac-git-policy.js` | Fixes the AC root, remote and `main` branch; classifies parent Ocha Git root; excludes runtime/credential material | `test/ac-auto-git-sync.test.js` | TESTED |
| `AC-GIT-SYNC` | Independent AC publisher | `src/core/ac-auto-git-sync.js` | Watches only `.private/artificial-consciousness-component`, path-scoped staging, secret scan, symlink/special-file rejection, separate AC_GITHUB_PAT and no force-push | `test/ac-auto-git-sync.test.js` | TESTED statically; no live push |
| `AC-GIT-SETUP` | History-preserving nested setup | `scripts/ac-git-setup.js` | Clones canonical AC remote first, compares package version/tree, backs up local snapshot, atomically promotes nested Git checkout | `test/ac-auto-git-sync.test.js` (policy helpers); live Git simulation pending | ADAPTER_READY; remote setup not verified |
| `AUTOPUSH-COMMAND` | Owner-private controls | `src/plugins/owner/autopush.js` | `.autopush` status/on/off/push/setup; aliases `.gitpush`, `.autogit`; hidden from menus; owner-only and private-chat-only | `test/menu-real-plugin-inventory.test.js` | TESTED; no collisions |
| `ENV-AC-TOKEN` | Secret inventory/config disclosure | `.env.example`, `scripts/lib/env-inventory.js`, `src/core/config-disclosure.js` | Separate AC_GITHUB_PAT placeholder, secret classification and status-only disclosure | `test/env-inventory.test.js` (requires Acorn dependency) | SOURCE UPDATED; regeneration pending dependency install |
| `AC-GIT-EXCLUSIONS` | AC repository hygiene | `.private/artificial-consciousness-component/.gitignore`, `src/core/ac-git-policy.js` | Excludes credentials stores, private keys/certificates, local service accounts, databases, ledgers and runtime output | `test/ac-auto-git-sync.test.js`, `test/release-policy.test.js` | TESTED |
| `TWO-BASE-RELEASE` | Dual source packaging | `scripts/release-two-bases.js`, `scripts/release-policy.js` | Emits private Ocha operator ZIP with selected AC source and a separate AC ZIP; omits nested `.git`, automation config, secrets and runtime data | `test/release-policy.test.js` | TESTED; package assembly pending final archive audit |

## Command and script registry

- Preserved: `npm run git:setup`, `npm run git:watch` (legacy Ocha-only CLI scripts).
- Added: `npm run ac:git:setup`, `npm run ac:git:watch`, `npm run git:status`, `npm run git:push`, `npm run git:push:ocha`, `npm run git:push:ac`.
- Hidden owner control: `.autopush` with aliases `.gitpush` and `.autogit`; metadata `ownerOnly: true`, `privateOnly: true`, `menu: false`.
- Targets are fixed in source: `razzaqinspires/ocha-lidya-whatsapp-bot:main` and `razzaqinspires/artificial-consciousness-component:main`. No arbitrary repository target is accepted by the command.

## Security and publication boundary

The Ocha root `.gitignore` excludes all `.private/`. The Ocha watcher never traverses that directory and additionally checks `git ls-files -- .private` before any commit. The AC watcher has a separate Git top-level root and cannot add paths to the Ocha index. Both lanes use separate least-privilege credentials, temporary askpass scripts, fixed remotes/branches, ancestry checks, path-scoped staging and no force-push. The Ocha operator archive includes selected `.private` source for deployment convenience and must never be uploaded to a public repository.

## AC continuity

The AC model source remains v2.1.1. This change modifies repository placement, ignore policy, and publication orchestration only; it does not modify MIMPI, INTEROCEPTION, NEURO, or NADI equations/algorithms. Continue the AC maintenance loop with heartbeat drift tests, overlapping MIMPI-window deduplication, and interoception numerical stability experiments.
