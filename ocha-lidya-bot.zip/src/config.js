/**
 * Ocha Lidya public configuration facade.
 * Non-secret settings are persisted in the JSONL event database.
 * Secrets belong in .env and must never be written to this database.
 */
import { initializeDatabase, appendRecord, getRecords, getLatestConfigRecord, configureDatabase } from './core/database.js';

const DEFAULTS = Object.freeze({
  schemaVersion: 38,
  bot: { name: 'Ocha Lidya', aliases: ['Ocha', 'Lidya'], owner: '6283193905842', ownerName: 'Arifi Razzaq', creatorName: 'Arifi Razzaq', organization: 'Razzaq Ventures', publicCreatorDisclosure: true, expectedNumber: '6282177461231' },
  whatsapp: { authMode: 'pairing', pairingNumber: '6282177461231', browserName: 'Chrome', sessionDir: 'sessions/ocha-lidya', recoverInvalidSession: true, connectTimeoutMs: 60000, queryTimeoutMs: 60000, keepAliveIntervalMs: 25000 },
  logging: { level: 'info', color: 'auto', timeZone: 'Asia/Jakarta' },
  mode: 'public',
  ui: {
    buttonsEnabled: true,
    fullButton: { enabled: false, strategy: 'adaptive', maxBodyChars: 1800, excludedCommands: [] },
    autoReactions: { enabled: false, commandEmoji: '⏳', thinkingEmoji: '💭', successEmoji: '✅', failureEmoji: '❌' }
  },
  menu: {
    showDescriptions: false,
    template: 'corporate',
    font: 'normal',
    order: 'category',
    spacing: 0,
    topBorder: true,
    bottomBorder: true,
    pagination: { enabled: false, pageSize: 50 }
  },
  commandGuard: { cooldown: { enabled: false }, antiSpam: { enabled: false, dailyWarnings: 5 } },
  groupMetadata: { initialSync: true, fetchCooldownMs: 600000 },
  prefix: { mode: 'multi', single: '.', list: ['.', '!', '/', '#'] },
  commands: { caseSensitive: false, ignoreEmpty: true },
  security: {
    ownerOnlyInGroups: false,
    allowMasterInGroups: false,
    masterEvalEnabled: false,
    masterEvalTemplateEnabled: true,
    masterCliEnabled: false,
    masterPythonEnabled: false,
    masterGolangEnabled: false,
    masterWorkloadWarningMode: 'compact',
    masterWorkloadReviewEnabled: true
  },
  limits: { messageMaxChars: 12000, pluginTimeoutMs: 15000, masterTimeoutMs: 8000, masterMaxOutput: 12000 },
  database: {
    segmentMaxBytes: 8 * 1024 * 1024,
    archiveMaxCount: 120,
    mirrorEnabled: true,
    fsync: true,
    verifyOnBoot: true
  },
  features: { autoRead: false, autoTyping: false, selfModeReply: false, groupsMuted: true, groupMuteOverrides: {}, lastJoinedGroupId: '' },
  ai: { enabled: true, providerOrder: ['groq', 'gemini', 'deepseek', 'openai'], models: { gemini: 'gemini-3.8-flash', groq: 'openai/gpt-oss-120b', deepseek: 'deepseek-flash', openai: 'gpt-6.2-sol' }, freeOnly: true, timeoutMs: 60000, totalBudgetMs: 180000, maxOutputTokens: 4096, temperature: 0.55, historyMessages: 96, maxInputChars: 96000, coalesceMs: 100 },
  youtube: { ytDlpBin: 'yt-dlp', ffmpegLocation: '', maxDownloadMb: 48, maxDurationSeconds: 1800, searchResults: 5 },
  codeLab: { enabled: true, aiExecutionEnabled: true, publicTunnelEnabled: true, websiteBuilderEnabled: true, websiteBuilderConcurrency: 2, websiteBuilderQueueLimit: 8, tunnelIdleMs: 300000, projectLibraryRoot: '', cloudflaredBin: 'cloudflared', containerRuntime: 'auto', port: 8787, ttlMs: 3600000, maxRuntimeMs: 120000, maxSourceBytes: 65536, maxOutputBytes: 49152, maxConcurrent: 2, maxSessionsTotal: 20, maxSessionsPerUser: 2, maxExecutionsPerMinute: 3, pythonImage: 'python:3.12-alpine', nodeImage: 'node:22-alpine' }
});

let activeConfig = structuredClone(DEFAULTS);
let initialized = false;

function merge(base, patch) {
  if (!patch || typeof patch !== 'object' || Array.isArray(patch)) return base;
  const out = structuredClone(base);
  for (const [key, value] of Object.entries(patch)) {
    if (value && typeof value === 'object' && !Array.isArray(value) && out[key] && typeof out[key] === 'object' && !Array.isArray(out[key])) out[key] = merge(out[key], value);
    else out[key] = value;
  }
  return out;
}

export async function loadConfig() {
  await initializeDatabase();
  const events = await getRecords({ type: 'config.replace' });
  const checkpoint = await getLatestConfigRecord();
  activeConfig = structuredClone(DEFAULTS);
  for (const event of events) activeConfig = merge(activeConfig, event.payload.config);
  const lastEvent = events.at(-1);
  if (checkpoint && (!lastEvent || checkpoint.ts >= lastEvent.ts)) {
    activeConfig = merge(activeConfig, checkpoint.payload.config);
  }
  // v1.4.2 migration: previous releases defaulted to QR. Move old installations
  // to pairing mode once so the shipped config.js default actually takes effect.
  if (!Number.isInteger(activeConfig.schemaVersion) || activeConfig.schemaVersion < 4) {
    activeConfig.schemaVersion = 4;
    activeConfig.whatsapp = { ...DEFAULTS.whatsapp, ...(activeConfig.whatsapp || {}), authMode: 'pairing' };
    await appendRecord('config.replace', {
      config: activeConfig,
      changedBy: 'system:migration',
      reason: 'v1.4.2 default WhatsApp login mode changed to pairing'
    });
  }
  // v1.4.3: browserName is a protocol identity, not the bot's display name.
  // Normalize existing installations to the known-compatible Chrome profile once.
  if (activeConfig.schemaVersion < 5) {
    activeConfig.schemaVersion = 5;
    activeConfig.whatsapp = {
      ...DEFAULTS.whatsapp,
      ...(activeConfig.whatsapp || {}),
      browserName: DEFAULTS.whatsapp.browserName
    };
    await appendRecord('config.replace', {
      config: activeConfig,
      changedBy: 'system:migration',
      reason: 'v1.4.3 normalize WhatsApp pairing browser identity to Chrome'
    });
  }
  // v1.4.4: add safe invalid-session quarantine and structured terminal logging.
  if (activeConfig.schemaVersion < 6) {
    activeConfig.schemaVersion = 6;
    activeConfig.whatsapp = {
      ...DEFAULTS.whatsapp,
      ...(activeConfig.whatsapp || {}),
      recoverInvalidSession: DEFAULTS.whatsapp.recoverInvalidSession
    };
    activeConfig.logging = { ...DEFAULTS.logging, ...(activeConfig.logging || {}) };
    await appendRecord('config.replace', {
      config: activeConfig,
      changedBy: 'system:migration',
      reason: 'v1.4.4 add invalid-session recovery and terminal logger settings'
    });
  }
  activeConfig.ui = merge(DEFAULTS.ui, activeConfig.ui || {});
  // v1.5.0: persist interactive-response mode.
  if (activeConfig.schemaVersion < 7) {
    activeConfig.schemaVersion = 7;
    activeConfig.ui = merge(DEFAULTS.ui, activeConfig.ui || {});
    await appendRecord('config.replace', {
      config: activeConfig,
      changedBy: 'system:migration',
      reason: 'v1.5.0 add owner-controlled interactive command responses'
    });
  }
  // v1.5.0: low-latency AI profile and explicit group metadata cache policy.
  if (activeConfig.schemaVersion < 8) {
    activeConfig.schemaVersion = 8;
    activeConfig.groupMetadata = { ...DEFAULTS.groupMetadata, ...(activeConfig.groupMetadata || {}) };
    const ai = activeConfig.ai || (activeConfig.ai = {});
    ai.models = { ...DEFAULTS.ai.models, ...(ai.models || {}) };
    const previousDefaultOrder = ['gemini', 'groq', 'qwen', 'deepseek', 'openai'];
    if (JSON.stringify(ai.providerOrder) === JSON.stringify(previousDefaultOrder)) ai.providerOrder = [...DEFAULTS.ai.providerOrder];
    if (ai.models.groq === 'openai/gpt-oss-120b') ai.models.groq = DEFAULTS.ai.models.groq;
    if (ai.models.gemini === 'gemini-3.6-flash') ai.models.gemini = DEFAULTS.ai.models.gemini;
    if ([8500, 35000].includes(ai.timeoutMs)) ai.timeoutMs = DEFAULTS.ai.timeoutMs;
    if ([22000, 35000].includes(ai.totalBudgetMs) || !Number.isInteger(ai.totalBudgetMs)) ai.totalBudgetMs = DEFAULTS.ai.totalBudgetMs;
    if ([700, 1200].includes(ai.maxOutputTokens)) ai.maxOutputTokens = DEFAULTS.ai.maxOutputTokens;
    if ([10, 16].includes(ai.historyMessages)) ai.historyMessages = DEFAULTS.ai.historyMessages;
    if (ai.maxInputChars === 10000) ai.maxInputChars = DEFAULTS.ai.maxInputChars;
    if (!Number.isInteger(ai.coalesceMs)) ai.coalesceMs = DEFAULTS.ai.coalesceMs;
    await appendRecord('config.replace', {
      config: activeConfig,
      changedBy: 'system:migration',
      reason: 'v1.5.0 low-latency AI settings and one-time group metadata cache policy'
    });
  }
  // v1.5.0 schema v9: lower the default latency/output budget while preserving
  // owner-defined non-default values. This is a config.js + JSONL migration.
  if (activeConfig.schemaVersion < 9) {
    activeConfig.schemaVersion = 9;
    const ai = activeConfig.ai || (activeConfig.ai = {});
    if (ai.timeoutMs === 6500) ai.timeoutMs = DEFAULTS.ai.timeoutMs;
    if (ai.totalBudgetMs === 16000) ai.totalBudgetMs = DEFAULTS.ai.totalBudgetMs;
    if (ai.maxOutputTokens === 500) ai.maxOutputTokens = DEFAULTS.ai.maxOutputTokens;
    if (ai.historyMessages === 8) ai.historyMessages = DEFAULTS.ai.historyMessages;
    if (ai.coalesceMs === 180) ai.coalesceMs = DEFAULTS.ai.coalesceMs;
    await appendRecord('config.replace', {
      config: activeConfig,
      changedBy: 'system:migration',
      reason: 'v1.5.0 schema v9 lower-latency AI response profile'
    });
  }
  // v1.6.0 schema v10: remove Qwen from routing and remove the per-provider key-attempt cap.
  if (activeConfig.schemaVersion < 10) {
    activeConfig.schemaVersion = 10;
    const ai = activeConfig.ai || (activeConfig.ai = {});
    ai.providerOrder = (Array.isArray(ai.providerOrder) ? ai.providerOrder : DEFAULTS.ai.providerOrder).filter(name => name !== 'qwen');
    if (!ai.providerOrder.length) ai.providerOrder = [...DEFAULTS.ai.providerOrder];
    if (ai.models) delete ai.models.qwen;
    ai.models = { ...DEFAULTS.ai.models, ...(ai.models || {}) };
    delete ai.maxKeyAttempts;
    delete ai.retryPerProvider;
    if (ai.totalBudgetMs === 12000 || ai.totalBudgetMs === 16000) ai.totalBudgetMs = DEFAULTS.ai.totalBudgetMs;
    await appendRecord('config.replace', { config: activeConfig, changedBy: 'system:migration', reason: 'v1.6.0 remove Qwen and enable exhaustive per-provider API-key rotation' });
  }
  // v1.6.2 schema v11: make each developer runner independent and mute all
  // group interactions by default while retaining metadata/contact event processing.
  if (activeConfig.schemaVersion < 11) {
    activeConfig.schemaVersion = 11;
  activeConfig.security = { ...DEFAULTS.security, ...(activeConfig.security || {}) };
    delete activeConfig.security.masterExecEnabled;
    activeConfig.features = { ...DEFAULTS.features, ...(activeConfig.features || {}) };
    if (typeof activeConfig.features.groupsMuted !== 'boolean') activeConfig.features.groupsMuted = true;
    await appendRecord('config.replace', {
      config: activeConfig,
      changedBy: 'system:migration',
      reason: 'v1.6.2 independent master runners and default global group mute'
    });
  }
  // v1.7.1 schema v12: low-latency AI boost. Migrate only known shipped defaults;
  // preserve any owner-customized timeout, model, history, and output settings.
  if (activeConfig.schemaVersion < 12) {
    activeConfig.schemaVersion = 12;
    const ai = activeConfig.ai || (activeConfig.ai = {});
    const shipped = { timeoutMs: 7000, totalBudgetMs: 45000, maxOutputTokens: 320, temperature: 0.6, historyMessages: 6, maxInputChars: 6000, coalesceMs: 350 };
    const boosted = { timeoutMs: 3500, totalBudgetMs: 14000, maxOutputTokens: 180, temperature: 0.5, historyMessages: 3, maxInputChars: 3500, coalesceMs: 80, maxKeyAttempts: 3 };
    for (const [key, oldValue] of Object.entries(shipped)) if (ai[key] === oldValue) ai[key] = boosted[key];
    ai.maxKeyAttempts = 1;
    await appendRecord('config.replace', { config: activeConfig, changedBy: 'system:migration', reason: 'v1.7.1 low-latency AI boost profile' });
  }
  // v1.7.2 schema v13: add owner master workload guard without enabling runners.
  if (activeConfig.schemaVersion < 13) {
    activeConfig.schemaVersion = 13;
    await appendRecord('config.replace', { config: activeConfig, changedBy: 'system:migration', reason: 'v1.7.2 owner master workload guard and eval runtime context' });
  }
  // v1.7.3 schema v14: redact Signal session dumps and keep runtime directories
  // outside filesystem watchers. Logging color remains auto unless overridden.
  if (activeConfig.schemaVersion < 14) {
    activeConfig.schemaVersion = 14;
    activeConfig.logging = { ...DEFAULTS.logging, ...(activeConfig.logging || {}) };
    await appendRecord('config.replace', { config: activeConfig, changedBy: 'system:migration', reason: 'v1.7.3 secure terminal logging and runtime watcher exclusions' });
  }
  // v1.8.0 schema v15: add isolated multi-session Code Lab and Nexora capability controls.
  if (activeConfig.schemaVersion < 15) {
    activeConfig.schemaVersion = 15;
    activeConfig.codeLab = { ...DEFAULTS.codeLab, ...(activeConfig.codeLab || {}) };
    await appendRecord('config.replace', { config: activeConfig, changedBy: 'system:migration', reason: 'v1.8.0 isolated Code Lab workers and temporary TryCloudflare preview sessions' });
  }
  // v1.8.1 schema v16: persist one always-on Quick Tunnel per bot process,
  // bundle owner activation controls, and use a lower-memory worker default.
  if (activeConfig.schemaVersion < 16) {
    activeConfig.schemaVersion = 16;
    activeConfig.codeLab = { ...DEFAULTS.codeLab, ...(activeConfig.codeLab || {}) };
    if (activeConfig.codeLab.maxConcurrent === 3) activeConfig.codeLab.maxConcurrent = 2;
    else if (Number(activeConfig.codeLab.maxConcurrent) > 4) activeConfig.codeLab.maxConcurrent = 4;
    await appendRecord('config.replace', { config: activeConfig, changedBy: 'system:migration', reason: 'v1.8.1 persistent single tunnel and bounded low-memory worker pool' });
  }
  // v1.9.0 schema v17: enable the multi-file static website builder capability.
  if (activeConfig.schemaVersion < 17) {
    activeConfig.schemaVersion = 17;
    activeConfig.codeLab = { ...DEFAULTS.codeLab, ...(activeConfig.codeLab || {}) };
    if (typeof activeConfig.codeLab.websiteBuilderEnabled !== 'boolean') activeConfig.codeLab.websiteBuilderEnabled = true;
    await appendRecord('config.replace', { config: activeConfig, changedBy: 'system:migration', reason: 'v1.9.0 Nexora multi-file website builder capability' });
  }
  // v1.10.0 schema v18: public creator identity and relationship/profile engine defaults.
  if (activeConfig.schemaVersion < 18) {
    activeConfig.schemaVersion = 18;
    activeConfig.bot = { ...DEFAULTS.bot, ...(activeConfig.bot || {}) };
    activeConfig.ai = { ...DEFAULTS.ai, ...(activeConfig.ai || {}) };
    // v1.7.1 shipped maxKeyAttempts=1 as its fast default; v1.10 rotates up to
    // three eligible keys per provider to avoid repeatedly selecting one failing key.
    if (activeConfig.ai.maxKeyAttempts === 1) activeConfig.ai.maxKeyAttempts = 3;
    await appendRecord('config.replace', { config: activeConfig, changedBy: 'system:migration', reason: 'v1.10.0 public creator identity, relationship profiles, and fair provider key rotation' });
  }
  // v1.10.1 schema v19: on-demand shared Quick Tunnel lifecycle with
  // cross-process lease protection and configurable idle shutdown.
  if (activeConfig.schemaVersion < 19) {
    activeConfig.schemaVersion = 19;
    activeConfig.codeLab = { ...DEFAULTS.codeLab, ...(activeConfig.codeLab || {}) };
    if (!Number.isInteger(activeConfig.codeLab.tunnelIdleMs)) activeConfig.codeLab.tunnelIdleMs = DEFAULTS.codeLab.tunnelIdleMs;
    await appendRecord('config.replace', { config: activeConfig, changedBy: 'system:migration', reason: 'v1.10.1 on-demand shared Quick Tunnel, exclusive process lease, and idle shutdown lifecycle' });
  }
  // v1.10.2 schema v20: runtime auto-detection with Docker/Podman fallback.
  if (activeConfig.schemaVersion < 20) {
    activeConfig.schemaVersion = 20;
    activeConfig.codeLab = { ...DEFAULTS.codeLab, ...(activeConfig.codeLab || {}) };
    await appendRecord('config.replace', { config: activeConfig, changedBy: 'system:migration', reason: 'v1.10.2 adaptive container runtime discovery and fallback' });
  }
  // v1.10.4 schema v21: persistent per-user website repositories, task memory,
  // local version history, and configurable project-library root.
  if (activeConfig.schemaVersion < 21) {
    activeConfig.schemaVersion = 21;
    activeConfig.codeLab = { ...DEFAULTS.codeLab, ...(activeConfig.codeLab || {}) };
    if (typeof activeConfig.codeLab.projectLibraryRoot !== 'string') activeConfig.codeLab.projectLibraryRoot = '';
    await appendRecord('config.replace', { config: activeConfig, changedBy: 'system:migration', reason: 'v1.10.4 persistent isolated user project repositories and project memory' });
  }
  // v1.10.9 schema v22: ordered multi-provider fallback. Previous releases
  // intentionally persisted a single provider; keep that provider first, then
  // append the remaining supported providers as automatic fallback options.
  if (activeConfig.schemaVersion < 22) {
    activeConfig.schemaVersion = 22;
    const ai = activeConfig.ai || (activeConfig.ai = {});
    const supported = ['groq', 'gemini', 'deepseek', 'openai'];
    const currentOrder = Array.isArray(ai.providerOrder) ? ai.providerOrder.map(value => String(value || '').trim().toLowerCase()) : [];
    const normalizedOrder = [...new Set(currentOrder.filter(name => supported.includes(name)))];
    ai.providerOrder = !normalizedOrder.length
      ? [...DEFAULTS.ai.providerOrder]
      : normalizedOrder.length === 1
        ? [normalizedOrder[0], ...DEFAULTS.ai.providerOrder.filter(name => name !== normalizedOrder[0])]
        : normalizedOrder;
    delete ai.maxKeyAttempts;
    delete ai.retryPerProvider;
    ai.models = { ...DEFAULTS.ai.models, ...(ai.models || {}) };
    await appendRecord('config.replace', { config: activeConfig, changedBy: 'system:migration', reason: 'v1.10.9 ordered provider fallback with classified key/provider failure handling' });
  }
  // v1.10.10 schema v24: autonomous model discovery, independent 24-hour
  // catalog scheduling, and conservative free-tier routing defaults.
  if (activeConfig.schemaVersion < 24) {
    activeConfig.schemaVersion = 24;
    const ai = activeConfig.ai || (activeConfig.ai = {});
    if (typeof ai.freeOnly !== 'boolean') ai.freeOnly = true;
    ai.models = { ...DEFAULTS.ai.models, ...(ai.models || {}) };
    if (ai.models.groq === 'openai/gpt-oss-20b') ai.models.groq = DEFAULTS.ai.models.groq;
    await appendRecord('config.replace', { config: activeConfig, changedBy: 'system:migration', reason: 'v1.10.10 autonomous provider model catalog and free-tier-first routing' });
  }
  // v1.10.14 schema v25: per-group interaction mute overrides and last joined group target.
  if (activeConfig.schemaVersion < 25) {
    activeConfig.schemaVersion = 25;
    activeConfig.features = { ...DEFAULTS.features, ...(activeConfig.features || {}) };
    const savedOverrides = activeConfig.features.groupMuteOverrides;
    const validOverrides = savedOverrides && typeof savedOverrides === 'object' && !Array.isArray(savedOverrides)
      ? Object.entries(savedOverrides).filter(([id, muted]) => /^\d{5,30}(?:-\d{1,25})?@g\.us$/.test(id) && typeof muted === 'boolean')
      : [];
    activeConfig.features.groupMuteOverrides = Object.fromEntries(validOverrides);
    if (typeof activeConfig.features.lastJoinedGroupId !== 'string' || (activeConfig.features.lastJoinedGroupId && !/^\d{5,30}(?:-\d{1,25})?@g\.us$/.test(activeConfig.features.lastJoinedGroupId))) {
      activeConfig.features.lastJoinedGroupId = '';
    }
    await appendRecord('config.replace', { config: activeConfig, changedBy: 'system:migration', reason: 'v1.10.14 owner group join command and per-group mute state' });
  }
  // v1.10.15 schema v26: all existing groups start muted; owner enables
  // each group in-place with .mute off. The previous last-joined shortcut is
  // intentionally retired to avoid changing the wrong group from private chat.
  if (activeConfig.schemaVersion < 26) {
    activeConfig.schemaVersion = 26;
    activeConfig.features = { ...DEFAULTS.features, ...(activeConfig.features || {}) };
    activeConfig.features.groupsMuted = true;
    activeConfig.features.groupMuteOverrides = {};
    activeConfig.features.lastJoinedGroupId = '';
    await appendRecord('config.replace', { config: activeConfig, changedBy: 'system:migration', reason: 'v1.10.15 safe per-group activation: all groups muted until owner enables in target group' });
  }
  // v1.10.17 schema v27: global menu presentation and adaptive command governance.
  if (activeConfig.schemaVersion < 27) {
    activeConfig.schemaVersion = 27;
    activeConfig.menu = structuredClone(DEFAULTS.menu);
    activeConfig.commandGuard = structuredClone(DEFAULTS.commandGuard);
    await appendRecord('config.replace', { config: activeConfig, changedBy: 'system:migration', reason: 'v1.10.17 global menu settings and adaptive command governor defaults' });
  }
  // v1.10.21 schema v28: opt-in adaptive full-button routing. Existing
  // installations remain text-first until the verified owner enables it.
  activeConfig.ui = merge(DEFAULTS.ui, activeConfig.ui || {});
  if (activeConfig.schemaVersion < 28) {
    activeConfig.schemaVersion = 28;
    activeConfig.ui.fullButton = merge(DEFAULTS.ui.fullButton, activeConfig.ui.fullButton || {});
    await appendRecord('config.replace', {
      config: activeConfig,
      changedBy: 'system:migration',
      reason: 'v1.10.21 adaptive full-button command UI, explicit plugin exemptions and text-safe fallback'
    });
  }
  // v1.10.22 schema v29: grounded assistant, persistent opt-in memory,
  // WhatsApp-native output formatting, and bounded completion recovery.
  if (activeConfig.schemaVersion < 29) {
    activeConfig.schemaVersion = 29;
    const ai = activeConfig.ai || (activeConfig.ai = {});
    if ([180, 220].includes(ai.maxOutputTokens)) ai.maxOutputTokens = DEFAULTS.ai.maxOutputTokens;
    if ([3, 4].includes(ai.historyMessages)) ai.historyMessages = DEFAULTS.ai.historyMessages;
    if (ai.maxInputChars === 3500) ai.maxInputChars = DEFAULTS.ai.maxInputChars;
    if (ai.coalesceMs === 80) ai.coalesceMs = DEFAULTS.ai.coalesceMs;
    await appendRecord('config.replace', {
      config: activeConfig,
      changedBy: 'system:migration',
      reason: 'v1.10.22 grounded AI context, WhatsApp format normalization, and bounded completion recovery'
    });
  }
  // v1.10.23 schema v30: persistent private roo vault, long-running archive
  // retrieval, identity kernel, BigInt XP, and expanded AI completion budget.
  if (activeConfig.schemaVersion < 30) {
    activeConfig.schemaVersion = 30;
    const ai = activeConfig.ai || (activeConfig.ai = {});
    if (ai.timeoutMs === 3500) ai.timeoutMs = DEFAULTS.ai.timeoutMs;
    if (ai.totalBudgetMs === 14000) ai.totalBudgetMs = DEFAULTS.ai.totalBudgetMs;
    if (ai.maxOutputTokens === 900) ai.maxOutputTokens = DEFAULTS.ai.maxOutputTokens;
    if (ai.historyMessages === 8) ai.historyMessages = DEFAULTS.ai.historyMessages;
    if (ai.maxInputChars === 5000) ai.maxInputChars = DEFAULTS.ai.maxInputChars;
    await appendRecord('config.replace', {
      config: activeConfig,
      changedBy: 'system:migration',
      reason: 'v1.10.23 per-user encrypted roo archives, persona identity kernel, arbitrary-precision XP, and expanded AI generation budget'
    });
  }
  // v1.10.23.1 schema v31: extend the default reasoning/output window.
  // Migrate only exact prior shipped values; user-tuned settings are preserved.
  if (activeConfig.schemaVersion < 31) {
    activeConfig.schemaVersion = 31;
    const ai = activeConfig.ai || (activeConfig.ai = {});
    if (ai.timeoutMs === 12000) ai.timeoutMs = DEFAULTS.ai.timeoutMs;
    if (ai.totalBudgetMs === 45000) ai.totalBudgetMs = DEFAULTS.ai.totalBudgetMs;
    if (ai.maxOutputTokens === 4096) ai.maxOutputTokens = DEFAULTS.ai.maxOutputTokens;
    if (ai.historyMessages === 20) ai.historyMessages = DEFAULTS.ai.historyMessages;
    if (ai.maxInputChars === 16000) ai.maxInputChars = DEFAULTS.ai.maxInputChars;
    await appendRecord('config.replace', {
      config: activeConfig,
      changedBy: 'system:migration',
      reason: 'v1.10.23 expanded adaptive AI context and provider-bounded completion budget'
    });
  }
  // v1.10.24 schema v32: enlarge the adaptive reasoning window while
  // preserving user-tuned settings and keeping provider/server ceilings explicit.
  if (activeConfig.schemaVersion < 32) {
    activeConfig.schemaVersion = 32;
    const ai = activeConfig.ai || (activeConfig.ai = {});
    if (ai.timeoutMs === 30000) ai.timeoutMs = DEFAULTS.ai.timeoutMs;
    if (ai.totalBudgetMs === 120000) ai.totalBudgetMs = DEFAULTS.ai.totalBudgetMs;
    if (ai.maxOutputTokens === 8192) ai.maxOutputTokens = DEFAULTS.ai.maxOutputTokens;
    if (ai.historyMessages === 24) ai.historyMessages = DEFAULTS.ai.historyMessages;
    if (ai.maxInputChars === 24000) ai.maxInputChars = DEFAULTS.ai.maxInputChars;
    await appendRecord('config.replace', {
      config: activeConfig,
      changedBy: 'system:migration',
      reason: 'v1.10.24 extended model context/output envelope and long-running reply continuity'
    });
  }
  // v1.10.25 schema v33: larger adaptive model envelope, relevance-ranked
  // memory context, and deadline-driven continuation without an attempt cap.
  // Only migrate exact v1.10.24 shipped defaults; owner-tuned values survive.
  if (activeConfig.schemaVersion < 33) {
    activeConfig.schemaVersion = 33;
    const ai = activeConfig.ai || (activeConfig.ai = {});
    if (ai.timeoutMs === 45000) ai.timeoutMs = DEFAULTS.ai.timeoutMs;
    if (ai.maxOutputTokens === 16384) ai.maxOutputTokens = DEFAULTS.ai.maxOutputTokens;
    if (ai.historyMessages === 48) ai.historyMessages = DEFAULTS.ai.historyMessages;
    if (ai.maxInputChars === 48000) ai.maxInputChars = DEFAULTS.ai.maxInputChars;
    await appendRecord('config.replace', {
      config: activeConfig,
      changedBy: 'system:migration',
      reason: 'v1.10.25 adaptive context expansion and deadline-driven completion'
    });
  }
  // v1.10.25 schema v34: expand the default conversational working set.
  // The encrypted archive remains unbounded at the application event-count
  // level; active context still follows provider and server resource ceilings.
  if (activeConfig.schemaVersion < 34) {
    activeConfig.schemaVersion = 34;
    const ai = activeConfig.ai || (activeConfig.ai = {});
    if (ai.historyMessages === 64) ai.historyMessages = DEFAULTS.ai.historyMessages;
    if (ai.maxInputChars === 64000) ai.maxInputChars = DEFAULTS.ai.maxInputChars;
    await appendRecord('config.replace', {
      config: activeConfig,
      changedBy: 'system:migration',
      reason: 'v1.10.25 expanded adaptive conversation and memory retrieval context'
    });
  }
  // v1.10.29 schema v35: controllable owner workload-warning UX and AI assessment.
  // Turning notifications off never disables static hard-blocks or the local risk gate.
  if (activeConfig.schemaVersion < 35) {
    activeConfig.schemaVersion = 35;
    activeConfig.security = { ...DEFAULTS.security, ...(activeConfig.security || {}) };
    if (!['compact', 'detailed', 'off'].includes(activeConfig.security.masterWorkloadWarningMode)) {
      activeConfig.security.masterWorkloadWarningMode = DEFAULTS.security.masterWorkloadWarningMode;
    }
    if (typeof activeConfig.security.masterWorkloadReviewEnabled !== 'boolean') {
      activeConfig.security.masterWorkloadReviewEnabled = DEFAULTS.security.masterWorkloadReviewEnabled;
    }
    await appendRecord('config.replace', {
      config: activeConfig,
      changedBy: 'system:migration',
      reason: 'v1.10.29 owner workload warning controls and AI review switch'
    });
  }
  // v1.10.33 schema v36: move YouTube executable and media caps into the
  // persisted non-secret application config; legacy env overrides are retired.
  if (activeConfig.schemaVersion < 36) {
    activeConfig.schemaVersion = 36;
    activeConfig.youtube = merge(DEFAULTS.youtube, activeConfig.youtube || {});
    await appendRecord('config.replace', {
      config: activeConfig,
      changedBy: 'system:migration',
      reason: 'v1.10.33 move YouTube non-secret runtime settings into application config'
    });
  }
  // v1.10.38 schema v37: add owner-controlled automatic message reactions.
  // Disabled by default so existing installations keep their previous UX.
  if (activeConfig.schemaVersion < 37) {
    activeConfig.schemaVersion = 37;
    activeConfig.ui = merge(DEFAULTS.ui, activeConfig.ui || {});
    await appendRecord('config.replace', {
      config: activeConfig,
      changedBy: 'system:migration',
      reason: 'v1.10.38 add owner-controlled automatic command and AI reactions'
    });
  }
  // v1.10.58 schema v38: add validated menu design settings while preserving
  // the existing global description/pagination preferences.
  if (activeConfig.schemaVersion < 38) {
    activeConfig.schemaVersion = 38;
    activeConfig.menu = merge(DEFAULTS.menu, activeConfig.menu || {});
    await appendRecord('config.replace', {
      config: activeConfig,
      changedBy: 'system:migration',
      reason: 'v1.10.58 add owner-controlled menu themes, fonts, ordering, spacing and borders'
    });
  }
  activeConfig.menu = merge(DEFAULTS.menu, activeConfig.menu || {});
  activeConfig.commandGuard = merge(DEFAULTS.commandGuard, activeConfig.commandGuard || {});
  activeConfig.security = { ...DEFAULTS.security, ...(activeConfig.security || {}) };
  delete activeConfig.security.masterExecEnabled;
  if (!['compact', 'detailed', 'off'].includes(activeConfig.security.masterWorkloadWarningMode)) activeConfig.security.masterWorkloadWarningMode = DEFAULTS.security.masterWorkloadWarningMode;
  if (typeof activeConfig.security.masterWorkloadReviewEnabled !== 'boolean') activeConfig.security.masterWorkloadReviewEnabled = DEFAULTS.security.masterWorkloadReviewEnabled;
  activeConfig.features = { ...DEFAULTS.features, ...(activeConfig.features || {}) };
  activeConfig.groupMetadata = { ...DEFAULTS.groupMetadata, ...(activeConfig.groupMetadata || {}) };
  activeConfig.codeLab = { ...DEFAULTS.codeLab, ...(activeConfig.codeLab || {}) };
  activeConfig.youtube = merge(DEFAULTS.youtube, activeConfig.youtube || {});
  activeConfig.ui = merge(DEFAULTS.ui, activeConfig.ui || {});
  configureDatabase(activeConfig.database);
  initialized = true;
  return getConfig();
}

export function getConfig() {
  if (!initialized) throw new Error('Config belum diinisialisasi. Panggil await loadConfig() saat startup.');
  return structuredClone(activeConfig);
}

export async function updateConfig(mutator, metadata = {}) {
  if (!initialized) await loadConfig();
  const next = structuredClone(activeConfig);
  await mutator(next);
  validateConfig(next);
  await appendRecord('config.replace', { config: next, changedBy: metadata.actor || 'system', reason: metadata.reason || 'configuration update' });
  activeConfig = next;
  activeConfig.ui = merge(DEFAULTS.ui, activeConfig.ui || {});
  configureDatabase(activeConfig.database);
  return getConfig();
}

export async function replaceConfig(next, metadata = {}) {
  if (!initialized) await loadConfig();
  const normalized = merge(DEFAULTS, next);
  validateConfig(normalized);
  await appendRecord('config.replace', { config: normalized, changedBy: metadata.actor || 'owner', reason: metadata.reason || 'configuration replacement' });
  activeConfig = normalized;
  activeConfig.ui = merge(DEFAULTS.ui, activeConfig.ui || {});
  configureDatabase(activeConfig.database);
  return getConfig();
}

function validateConfig(c) {
  if (!['public', 'self'].includes(c.mode)) throw new Error('mode harus public atau self');
  if (!['compact', 'detailed', 'off'].includes(c.security?.masterWorkloadWarningMode)) throw new Error('security.masterWorkloadWarningMode harus compact, detailed, atau off');
  if (typeof c.security?.masterWorkloadReviewEnabled !== 'boolean') throw new Error('security.masterWorkloadReviewEnabled harus boolean');
  if (typeof c.ui?.buttonsEnabled !== 'boolean') throw new Error('ui.buttonsEnabled harus boolean');
  if (typeof c.ui?.fullButton?.enabled !== 'boolean') throw new Error('ui.fullButton.enabled harus boolean');
  if (c.ui?.fullButton?.strategy !== 'adaptive') throw new Error('ui.fullButton.strategy harus adaptive');
  if (!Number.isInteger(c.ui?.fullButton?.maxBodyChars) || c.ui.fullButton.maxBodyChars < 300 || c.ui.fullButton.maxBodyChars > 3500) throw new Error('ui.fullButton.maxBodyChars harus 300-3500');
  if (!Array.isArray(c.ui?.fullButton?.excludedCommands) || c.ui.fullButton.excludedCommands.some(value => typeof value !== 'string' || !/^[a-z0-9][a-z0-9_-]{0,39}$/i.test(value))) throw new Error('ui.fullButton.excludedCommands harus array nama command yang valid');
  if (typeof c.ui?.autoReactions?.enabled !== 'boolean') throw new Error('ui.autoReactions.enabled harus boolean');
  for (const key of ['commandEmoji', 'thinkingEmoji', 'successEmoji', 'failureEmoji']) {
    const value = c.ui?.autoReactions?.[key];
    if (typeof value !== 'string' || !value.trim() || [...value].length > 8) throw new Error(`ui.autoReactions.${key} harus emoji teks 1-8 karakter`);
  }
  if (typeof c.menu?.showDescriptions !== 'boolean') throw new Error('menu.showDescriptions harus boolean');
  if (!['corporate', 'minimal', 'terminal', 'elegant', 'aurora', 'classic', 'compact', 'minimalist', 'cyberpunk', 'fantasy', 'ocean', 'sunset', 'emerald', 'sakura', 'monochrome', 'royal'].includes(c.menu?.template)) throw new Error('menu.template tidak dikenal');
  if (!['normal', 'bolditalic', 'bold', 'sans', 'mono', 'superscript', 'double', 'smallcaps', 'fraktur', 'italic', 'script', 'circled'].includes(c.menu?.font)) throw new Error('menu.font tidak dikenal');
  if (!['category', 'az', 'za'].includes(c.menu?.order)) throw new Error('menu.order harus category, az, atau za');
  if (!Number.isInteger(c.menu?.spacing) || c.menu.spacing < 0 || c.menu.spacing > 3) throw new Error('menu.spacing harus 0-3');
  if (typeof c.menu?.topBorder !== 'boolean' || typeof c.menu?.bottomBorder !== 'boolean') throw new Error('menu borders harus boolean');
  if (typeof c.menu?.pagination?.enabled !== 'boolean') throw new Error('menu.pagination.enabled harus boolean');
  if (!Number.isInteger(c.menu?.pagination?.pageSize) || c.menu.pagination.pageSize < 10 || c.menu.pagination.pageSize > 200) throw new Error('menu.pagination.pageSize harus 10-200');
  if (typeof c.commandGuard?.cooldown?.enabled !== 'boolean' || typeof c.commandGuard?.antiSpam?.enabled !== 'boolean') throw new Error('commandGuard flags harus boolean');
  if (c.commandGuard?.antiSpam?.dailyWarnings !== 5) throw new Error('commandGuard.antiSpam.dailyWarnings saat ini ditetapkan 5');

  if (typeof c.features?.groupsMuted !== 'boolean') throw new Error('features.groupsMuted harus boolean');
  if (!c.features?.groupMuteOverrides || typeof c.features.groupMuteOverrides !== 'object' || Array.isArray(c.features.groupMuteOverrides)) throw new Error('features.groupMuteOverrides harus object');
  for (const [groupId, muted] of Object.entries(c.features.groupMuteOverrides)) {
    if (!/^\d{5,30}(?:-\d{1,25})?@g\.us$/.test(groupId) || typeof muted !== 'boolean') throw new Error('features.groupMuteOverrides berisi Group JID atau status mute tidak valid');
  }
  if (typeof c.features?.lastJoinedGroupId !== 'string' || (c.features.lastJoinedGroupId && !/^\d{5,30}(?:-\d{1,25})?@g\.us$/.test(c.features.lastJoinedGroupId))) throw new Error('features.lastJoinedGroupId harus Group JID atau string kosong');
  if (typeof c.groupMetadata?.initialSync !== 'boolean') throw new Error('groupMetadata.initialSync harus boolean');
  if (!Number.isInteger(c.groupMetadata?.fetchCooldownMs) || c.groupMetadata.fetchCooldownMs < 1000 || c.groupMetadata.fetchCooldownMs > 86400000) throw new Error('groupMetadata.fetchCooldownMs harus 1000-86400000');
  if (!['qr', 'pairing'].includes(c.whatsapp?.authMode)) throw new Error('whatsapp.authMode harus qr atau pairing');
  if (!['Chrome', 'Firefox', 'IE', 'Opera', 'Safari', 'Edge'].includes(c.whatsapp?.browserName)) throw new Error('whatsapp.browserName harus Chrome, Firefox, IE, Opera, Safari, atau Edge');
  if (typeof c.whatsapp?.recoverInvalidSession !== 'boolean') throw new Error('whatsapp.recoverInvalidSession harus boolean');
  if (!['trace', 'debug', 'info', 'warn', 'error', 'fatal', 'silent'].includes(c.logging?.level)) throw new Error('logging.level tidak valid');
  if (!['auto', 'always', 'never'].includes(c.logging?.color)) throw new Error('logging.color harus auto, always, atau never');
  if (typeof c.logging?.timeZone !== 'string' || !c.logging.timeZone.trim()) throw new Error('logging.timeZone wajib diisi');
  if (!/^\d{8,15}$/.test(String(c.whatsapp?.pairingNumber || c.bot?.expectedNumber || ''))) throw new Error('whatsapp.pairingNumber harus nomor internasional 8-15 digit tanpa +');
  if (typeof c.whatsapp?.sessionDir !== 'string' || !c.whatsapp.sessionDir.trim()) throw new Error('whatsapp.sessionDir wajib diisi');
  if (!['single', 'multi', 'none'].includes(c.prefix?.mode)) throw new Error('prefix.mode tidak valid');
  if (!/^\d{8,15}$/.test(String(c.bot?.owner || ''))) throw new Error('bot.owner harus berupa nomor internasional tanpa +');
  for (const key of ['ownerName', 'creatorName', 'organization']) if (typeof c.bot?.[key] !== 'string' || !c.bot[key].trim() || c.bot[key].length > 80) throw new Error(`bot.${key} wajib berupa teks 1-80 karakter`);
  if (typeof c.bot?.publicCreatorDisclosure !== 'boolean') throw new Error('bot.publicCreatorDisclosure harus boolean');
  if (!Number.isInteger(c.database?.segmentMaxBytes) || c.database.segmentMaxBytes < 65536) throw new Error('database.segmentMaxBytes minimal 65536');
  if (!Number.isInteger(c.database?.archiveMaxCount) || c.database.archiveMaxCount < 1) throw new Error('database.archiveMaxCount minimal 1');
  if (c.ai && (!Array.isArray(c.ai.providerOrder) || c.ai.providerOrder.some(name => !['gemini','groq','deepseek','openai'].includes(name)))) throw new Error('ai.providerOrder berisi provider tidak dikenal');
  if (c.ai && typeof c.ai.freeOnly !== 'boolean') throw new Error('ai.freeOnly harus boolean');
  if (c.ai && (!Number.isInteger(c.ai.timeoutMs) || c.ai.timeoutMs < 1000 || c.ai.timeoutMs > 180000)) throw new Error('ai.timeoutMs harus 1000-180000');
  if (c.ai && (!Number.isInteger(c.ai.totalBudgetMs) || c.ai.totalBudgetMs < 3000 || c.ai.totalBudgetMs > 180000)) throw new Error('ai.totalBudgetMs harus 3000-180000');
  if (c.ai && (!Number.isInteger(c.ai.coalesceMs) || c.ai.coalesceMs < 0 || c.ai.coalesceMs > 2000)) throw new Error('ai.coalesceMs harus 0-2000');
  if (c.ai && (!Number.isInteger(c.ai.maxOutputTokens) || c.ai.maxOutputTokens < 64 || c.ai.maxOutputTokens > 32768)) throw new Error('ai.maxOutputTokens harus 64-32768');
  if (c.ai && (!Number.isInteger(c.ai.maxInputChars) || c.ai.maxInputChars < 1000 || c.ai.maxInputChars > 128000)) throw new Error('ai.maxInputChars harus 1000-128000');
  if (c.ai && (!Number.isInteger(c.ai.historyMessages) || c.ai.historyMessages < 2 || c.ai.historyMessages > 256)) throw new Error('ai.historyMessages harus 2-256');
  for (const key of ['enabled', 'aiExecutionEnabled', 'publicTunnelEnabled', 'websiteBuilderEnabled']) if (typeof c.codeLab?.[key] !== 'boolean') throw new Error(`codeLab.${key} harus boolean`);
  if (!Number.isInteger(c.codeLab?.websiteBuilderConcurrency) || c.codeLab.websiteBuilderConcurrency < 1 || c.codeLab.websiteBuilderConcurrency > 4) throw new Error('codeLab.websiteBuilderConcurrency harus 1-4');
  if (!Number.isInteger(c.codeLab?.websiteBuilderQueueLimit) || c.codeLab.websiteBuilderQueueLimit < 0 || c.codeLab.websiteBuilderQueueLimit > 40) throw new Error('codeLab.websiteBuilderQueueLimit harus 0-40');
  if (!Number.isInteger(c.codeLab?.tunnelIdleMs) || c.codeLab.tunnelIdleMs < 0 || c.codeLab.tunnelIdleMs > 3600000) throw new Error('codeLab.tunnelIdleMs harus 0-3600000');
  if (!Number.isInteger(c.codeLab?.port) || c.codeLab.port < 1024 || c.codeLab.port > 65535) throw new Error('codeLab.port harus 1024-65535');
  if (!Number.isInteger(c.codeLab?.ttlMs) || c.codeLab.ttlMs < 60000 || c.codeLab.ttlMs > 3600000) throw new Error('codeLab.ttlMs harus 60000-3600000');
  if (!Number.isInteger(c.codeLab?.maxRuntimeMs) || c.codeLab.maxRuntimeMs < 5000 || c.codeLab.maxRuntimeMs > 600000) throw new Error('codeLab.maxRuntimeMs harus 5000-600000');
  if (!Number.isInteger(c.codeLab?.maxConcurrent) || c.codeLab.maxConcurrent < 1 || c.codeLab.maxConcurrent > 4) throw new Error('codeLab.maxConcurrent harus 1-4');
  if (!Number.isInteger(c.codeLab?.maxSessionsTotal) || c.codeLab.maxSessionsTotal < 1 || c.codeLab.maxSessionsTotal > 100) throw new Error('codeLab.maxSessionsTotal harus 1-100');
  if (!Number.isInteger(c.codeLab?.maxSessionsPerUser) || c.codeLab.maxSessionsPerUser < 1 || c.codeLab.maxSessionsPerUser > 10) throw new Error('codeLab.maxSessionsPerUser harus 1-10');
  if (!Number.isInteger(c.codeLab?.maxSourceBytes) || c.codeLab.maxSourceBytes < 1024 || c.codeLab.maxSourceBytes > 262144) throw new Error('codeLab.maxSourceBytes harus 1024-262144');
  if (!Number.isInteger(c.codeLab?.maxOutputBytes) || c.codeLab.maxOutputBytes < 2048 || c.codeLab.maxOutputBytes > 49152) throw new Error('codeLab.maxOutputBytes harus 2048-49152');
  if (!['auto', 'docker', 'podman'].includes(c.codeLab?.containerRuntime)) throw new Error('codeLab.containerRuntime harus auto, docker, atau podman');
  if (typeof c.codeLab?.projectLibraryRoot !== 'string' || c.codeLab.projectLibraryRoot.length > 500) throw new Error('codeLab.projectLibraryRoot harus berupa path teks maksimal 500 karakter');
  for (const key of ['cloudflaredBin', 'pythonImage', 'nodeImage']) if (typeof c.codeLab?.[key] !== 'string' || !c.codeLab[key].trim()) throw new Error(`codeLab.${key} wajib diisi`);
  if (typeof c.youtube?.ytDlpBin !== 'string' || !c.youtube.ytDlpBin.trim() || c.youtube.ytDlpBin.length > 512) throw new Error('youtube.ytDlpBin wajib berupa nama/path executable maksimal 512 karakter');
  if (typeof c.youtube?.ffmpegLocation !== 'string' || c.youtube.ffmpegLocation.length > 512) throw new Error('youtube.ffmpegLocation harus berupa path teks maksimal 512 karakter');
  if (!Number.isInteger(c.youtube?.maxDownloadMb) || c.youtube.maxDownloadMb < 8 || c.youtube.maxDownloadMb > 128) throw new Error('youtube.maxDownloadMb harus 8-128');
  if (!Number.isInteger(c.youtube?.maxDurationSeconds) || c.youtube.maxDurationSeconds < 30 || c.youtube.maxDurationSeconds > 7200) throw new Error('youtube.maxDurationSeconds harus 30-7200');
  if (!Number.isInteger(c.youtube?.searchResults) || c.youtube.searchResults < 2 || c.youtube.searchResults > 8) throw new Error('youtube.searchResults harus 2-8');
}

export const configDefaults = DEFAULTS;
export default { loadConfig, getConfig, updateConfig, replaceConfig, configDefaults };
