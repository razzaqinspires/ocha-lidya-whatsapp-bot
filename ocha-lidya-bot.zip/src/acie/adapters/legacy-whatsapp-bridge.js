/**
 * Builds a review-only descriptor for contributor scripts written against the
 * legacy Baileys globals (conn, m). It never imports or executes contribution
 * source and never writes into the immutable contribution vault.
 */
export function buildLegacyWhatsAppBridgeDraft({ providerId, contributionId, analysis, capability } = {}) {
  if (!providerId || !contributionId || !analysis || !capability) {
    throw new TypeError('providerId, contributionId, analysis and capability are required.');
  }
  const integration = capability.integration || 'unknown';
  if (integration !== 'legacy-whatsapp-inline') {
    throw new Error('Capability is not identified as a legacy WhatsApp inline implementation.');
  }
  const fixedInput = capability.inputContract === 'fixed-content-in-source';
  const signals = (analysis.capabilitySignals || []).find(item => item.id === capability.id);
  const blockers = [
    'Source has no callable export; importing the original module would execute top-level code.',
    'Legacy globals conn and m require an explicit, reviewed bridge contract.',
    'External assets must be snapshotted and licensed before rendering.',
    'Canvas dependency must be pinned in an isolated runtime image.',
    'JSON-stdio request/response protocol has not been implemented or tested.'
  ];
  if (!signals) blockers.unshift('Capability evidence is missing from static analysis.');
  return {
    schemaVersion: 1,
    kind: 'adapter-draft',
    providerId,
    contributionId,
    protocol: 'legacy-whatsapp-inline-bridge-draft-v1',
    capability: capability.id,
    sourceMode: 'immutable-top-level-script',
    invocation: {
      mode: 'not-executable',
      dynamicInput: !fixedInput,
      input: fixedInput ? 'none; source text is hardcoded' : 'unverified',
      requiredGlobals: ['conn', 'm'],
      expectedOutput: capability.outputMimeType || 'image/jpeg'
    },
    evidence: signals?.evidence || [],
    dependencyCandidates: (analysis.dependencies || []).filter(item => item.declaredInManifest === false || item.source === 'code-import-discovery'),
    assetReferences: (analysis.externalAssetReferences || []).map(item => ({ file: item.file, url: item.url, status: 'external-reference-unverified' })),
    blockers,
    security: { sourceReadOnly: true, network: 'denied', botCredentials: 'denied', execute: false },
    review: { humanApprovalRequired: true, adapterReviewed: false, protocolTested: false, outputContractVerified: false },
    status: 'draft-only',
    createdAt: new Date().toISOString()
  };
}
