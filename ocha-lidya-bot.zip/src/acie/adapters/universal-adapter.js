import path from 'node:path';
import { safeRelativePath } from '../core/fs-safe.js';

const PROTOCOL = 'acie-json-stdio-v1';
const RUNTIME_COMMANDS = Object.freeze({
  javascript: { executable: 'node', args: [] },
  python: { executable: 'python3', args: [] },
  go: { executable: 'go', args: ['run'] },
  php: { executable: 'php', args: [] },
  java: { executable: 'java', args: [] },
  bash: { executable: 'bash', args: [] }
});

export function createExternalAdapterDescriptor({ providerId, contributionId, capabilities = [], entryPoint = null, language = 'unknown' } = {}) {
  const extensionLanguage = ({ '.js': 'javascript', '.cjs': 'javascript', '.mjs': 'javascript', '.py': 'python', '.go': 'go', '.php': 'php', '.java': 'java', '.sh': 'bash' })[path.extname(String(entryPoint || '')).toLowerCase()];
  const selectedLanguage = language === 'mixed' || language === 'unknown' ? (extensionLanguage || language) : language;
  const safeEntry = entryPoint ? safeRelativePath(String(entryPoint).replaceAll('\\', '/')) : null;
  return {
    schemaVersion: 1, providerId, contributionId, protocol: PROTOCOL,
    provider: { language: selectedLanguage, runtime: selectedLanguage === 'javascript' ? 'node' : selectedLanguage },
    capabilities: capabilities.map(item => ({ id: item.id, status: item.status || 'unverified' })),
    entryPoint: safeEntry,
    invocation: { mode: 'json-stdio', input: 'one JSON object on stdin', output: 'one JSON object on stdout', operation: null, exportName: null },
    execution: { enabled: false, network: 'denied', sourceMount: 'read-only', credentials: 'none' },
    validation: { adapterReviewed: false, protocolTested: false },
    createdAt: new Date().toISOString()
  };
}

export function validateAdapterDescriptor(adapter, provider, { allowReviewedExecution = false } = {}) {
  const errors = [];
  if (!adapter || adapter.protocol !== PROTOCOL) errors.push('unsupported-protocol');
  if (!adapter?.entryPoint) errors.push('entrypoint-missing');
  else { try { safeRelativePath(adapter.entryPoint); } catch { errors.push('unsafe-entrypoint'); } }
  if (adapter?.providerId !== provider?.providerId) errors.push('provider-mismatch');
  if (adapter?.contributionId !== provider?.contributionId) errors.push('contribution-mismatch');
  if (!RUNTIME_COMMANDS[adapter?.provider?.language]) errors.push('runtime-not-supported');
  if (adapter?.execution?.enabled !== false) errors.push('adapter-must-remain-disabled-until-reviewed');
  if (adapter?.invocation?.mode !== 'json-stdio-v1' && adapter?.invocation?.mode !== 'json-stdio') errors.push('unsupported-invocation-mode');
  if (!allowReviewedExecution && adapter?.validation?.adapterReviewed === true && adapter?.validation?.protocolTested === true) { /* reviewed descriptor remains valid for runtime */ }
  return { valid: errors.length === 0, errors, protocol: PROTOCOL };
}

export function getRuntimeCommand(language, entryPoint) {
  const spec = RUNTIME_COMMANDS[language];
  if (!spec) throw new Error(`Unsupported ACIE runtime language: ${language}. This language requires a separately validated build adapter.`);
  const relative = safeRelativePath(String(entryPoint || '').replaceAll('\\', '/'));
  const containerPath = path.posix.join('/acie/source', relative.split(path.sep).join('/'));
  return { executable: spec.executable, args: [...spec.args, containerPath] };
}

export function normalizeAdapterInput(input) {
  const serialized = JSON.stringify(input ?? {});
  if (Buffer.byteLength(serialized) > 256 * 1024) throw new Error('Adapter input exceeds 256 KiB.');
  return serialized;
}

export function normalizeAdapterOutput(stdout, { maxBytes = 1024 * 1024 } = {}) {
  const text = String(stdout || '').trim();
  if (!text || Buffer.byteLength(text) > maxBytes) throw Object.assign(new Error('Invalid or oversized adapter output.'), { code: 'INVALID_OUTPUT' });
  let parsed;
  try { parsed = JSON.parse(text); } catch { throw Object.assign(new Error('Adapter stdout must contain one JSON object.'), { code: 'INVALID_OUTPUT' }); }
  if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) throw Object.assign(new Error('Adapter output must be a JSON object.'), { code: 'INVALID_OUTPUT' });
  return parsed;
}
