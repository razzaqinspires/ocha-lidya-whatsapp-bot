## Paired compatibility metadata — Ocha v1.10.58 — 2026-11-28

- Advance only `OCHA_COMPONENT_RELEASE.json` compatibility metadata to Ocha v1.10.58.
- AC component version remains v2.1.1; Python runtime source, NADI HTTP API v1 contract, state model, formulas, and persistence are unchanged.
- This is a local paired-release snapshot; no AC Git commit or remote push is claimed.

## v2.1.1 — Ocha v1.10.57 dual-repository operations — 2026-11-27

- Keep the AC kernel/model release at v2.1.1; no mathematical model, MIMPI, INTEROCEPTION or NADI HTTP API behavior changed in this Ocha Git-automation update.
- Document the independent nested Git working tree at Ocha operator path `.private/artificial-consciousness-component`.
- Add AC-side `.gitignore` exclusions for credentials directories, service-account files, private keys/certificates, databases and runtime state; the Ocha release and AC watcher enforce matching deny rules.
- AC publication is authenticated separately using `AC_GITHUB_PAT`, with the canonical `main` branch and no force-push.
- AC auto-push runs only while the Ocha Node.js watcher is active; actual GitHub setup/push must be verified on the operator host.

# Changelog

## 2.1.1 — 2026-11-26

- MIMPI computes a SHA-256 fingerprint for the selected episodic window and skips an identical already-consolidated window, including after process restart.
- Add `EternalMemory.append_many()` so a related MIMPI output batch is committed through one atomic hash-chain ledger flush without rewriting historical blocks.
- INTEROCEPTION uses bounded one-second integration substeps for elapsed intervals up to the existing 300-second heartbeat cap.
- Apply `social_interaction` as a single impulse per update instead of reapplying it during numerical substeps.
- Reject negative, non-finite or over-300-second deltas before kernel tick state is mutated.
- Keep NADI HTTP API v1 contract unchanged.
- Add regression coverage for repeat-window idempotency, restart recovery, new-window processing, large-delta numerical stability and invalid-delta rejection.
- Paired with Ocha v1.10.57 as an independently nested private checkout; no Git commit SHA is claimed for the supplied source archive because it had no `.git` metadata. The operator setup clones the canonical remote before applying a higher-version snapshot.

## 2.1.0 — 2026-11-24

- Added process-exclusive ownership for each persistent state directory.
- Added drift-corrected managed heartbeat with clean lifecycle controls.
- Added sender-scoped pseudonymous private-memory ledgers.
- Added explicit non-persistent private stimulus handling and digest-only output commits.
- Added hardened loopback-first HTTP service with token checks for remote binding, request limits, rate limiting, and safer response headers.
- Added startup integrity checks and corrupt snapshot quarantine.
- Preserved Ocha v1.10.30 operational self-model wording and calibrated 1 Hz homeostasis coefficients.
- Added a one-hour heartbeat-calibration regression test.
- Updated package metadata, configuration template, and API documentation.
- Added repository ignore rules for credentials/runtime state and a Python 3.10–3.13 GitHub Actions CI workflow.


## 2.1.0 — Ocha v1.10.52 compatibility metadata

- Record the two-base release pin and Ocha HTTP API v1 compatibility in `OCHA_COMPONENT_RELEASE.json`.
- Keep the Python kernel, component tests, and secured sidecar independent from the Ocha Node.js repository. No kernel formula was changed in this release metadata update.


## 2.1.0 — Maintenance review 2026-11-26

- Record a repeat-cycle MIMPI consolidation risk and a large-delta INTEROCEPTION numeric-integration risk with measured experiments.
- Add `ARTIFICIAL_CONSCIOUSNESS_MAINTENANCE_REPORT.md`; no runtime formula, ledger format or component code was modified in this documentation-only review.
- Revalidate Python syntax, core self-tests and extended privacy/lifecycle tests.


## 2.1.0 — Ocha v1.10.52 paired release metadata

- Advance `compatibleOchaVersion` to `1.10.52` for the paired two-base release.
- Keep the AC package version, source commit, Python code, API v1 contract and algorithmic behavior unchanged.
