# AC-Kernel NADI 2.1.1

AC-Kernel NADI adalah komponen Python modular untuk mensimulasikan dan mengelola *operational self-state* agen: heartbeat terjadwal, homeostasis, model-diri prediktif, dinamika afektif sintetis, deliberasi kebijakan, konsolidasi memori, dan ledger integritas SHA-256. Komponen ini dirancang independen dari aplikasi host seperti Ocha Lidya AI.

> **Batas klaim:** nama proyek merujuk pada riset/arsitektur kesadaran buatan. Implementasi ini adalah model komputasional dan tidak membuktikan pengalaman subjektif, sentience, emosi biologis, atau kesadaran fenomenal.

## Perubahan 2.1.1

- MIMPI menggunakan fingerprint SHA-256 dari jendela episode; pemanggilan ulang pada jendela identik dilewati tanpa menggandakan insight atau memulihkan state dua kali.
- Konsolidasi multi-block ditulis melalui satu atomic ledger flush; block historis tetap append-only.
- INTEROCEPTION membatasi integrasi numerik ke substep maksimum 1 detik, memproses impuls interaksi sosial satu kali, dan menolak delta non-finite/negatif/lebih dari 300 detik.
- Tambahan regression untuk idempotensi setelah restart, jendela baru, stabilitas delta 300 detik, dan validasi input waktu.

## Perubahan 2.1.0

- Kernel lifecycle dengan OS process lock untuk mencegah dua writer memakai `data_dir` yang sama.
- Heartbeat background terkelola, idempotent, drift-corrected, dan menghindari *catch-up storm*.
- Ledger memori privat per-scope dengan direktori pseudonim berbasis salt; raw sender ID tidak ditulis ke nama direktori.
- Stimulasi privat dapat diproses tanpa menyimpan teks mentah (`persist_stimulus=False`).
- Snapshot korup dikarantina dan startup dihentikan dengan error eksplisit, bukan reset diam-diam.
- HTTP sidecar loopback-first dengan autentikasi Bearer untuk binding non-loopback, rate limit, pembatasan ukuran body, validasi JSON, timeout socket, dan respons tanpa cache.
- API `/v1/*` untuk health, status, heartbeat, perceive, commit digest, recall scope, tick, sleep, checkpoint, dan verifikasi.
- Kalibrasi homeostasis operasional 1 Hz dipertahankan agar cadangan energi dan beban komputasi tidak drift secara agresif selama heartbeat jangka panjang.
- Tetap provider-agnostic; host app tetap memegang satu-satunya rantai provider LLM.

## Struktur

```text
ac/
├── adapters.py          # Adapter LLM opsional (mock/OpenAI-compatible/Ollama/webhook)
├── appraise_llm.py      # Appraisal heuristik/LLM opsional
├── bridge.py            # Alur percakapan standalone
├── config.py            # ACConfig
├── diri.py              # Predictive self-model
├── ingat.py             # EternalMemory + SHA-256 chain
├── intero.py            # Homeostasis/interoception
├── kehendak.py          # Active inference / EFE
├── kernel.py            # Orkestrator dan lifecycle kernel
├── metrics.py           # Telemetri komputasional
├── mimpi.py             # Konsolidasi NREM/REM
├── nadi.py              # Heartbeat oscillator
├── neuro.py             # Neuromodulator state model
├── panggung.py          # Global workspace model
├── rasa.py              # Synthetic appraisal model
├── sapa.py              # Consent gate
├── server.py            # Secured HTTP sidecar
└── util.py              # I/O atomik dan utilitas
```

## Persyaratan dan instalasi

- Python 3.10 atau lebih baru.
- Tidak ada dependency pihak ketiga wajib; implementasi inti menggunakan standard library Python.
- Satu proses NADI per `data_dir`.

```bash
python --version
python selftest.py
python test_prime.py
python -m py_compile ac/*.py
python -m ac --config ac_config.example.json status
```

Buat konfigurasi aktif dari template sebelum menjalankan service:

```bash
cp ac_config.example.json ac_config.json
# Edit data_dir agar menunjuk ke penyimpanan persisten yang kamu inginkan.
python -m ac --config ac_config.json serve --host 127.0.0.1 --port 8765
```

Service memulai heartbeat otomatis saat server mulai. `Ctrl+C` menghentikan service; kernel menyimpan snapshot dan melepaskan process lock saat penutupan normal.

## HTTP API

Semua endpoint API berversi memakai prefix `/v1`.

| Method | Endpoint | Fungsi |
|---|---|---|
| GET | `/v1/health` | Health service, versi, heartbeat, dan validitas ledger |
| GET | `/v1/status` | Snapshot state operasional |
| GET | `/v1/verify` | Verifikasi hash-chain |
| GET | `/v1/heartbeat` | Status heartbeat |
| GET | `/v1/capabilities` | Kapabilitas service |
| POST | `/v1/heartbeat` | `{"action":"start","interval_sec":1}` atau `{"action":"stop"}` |
| POST | `/v1/perceive` | Proses satu input privat dalam scope sender tanpa menyimpan raw message |
| POST | `/v1/commit` | Simpan keyed digest dan jumlah karakter respons, bukan teks mentah |
| POST | `/v1/recall` | Recall ledger pada scope pengirim tertentu |
| POST | `/v1/tick` | Jalankan satu tick manual; stimulus privat harus menyertakan `sender_id` |
| POST | `/v1/sleep` | Konsolidasi memori global atau scope tertentu |
| POST | `/v1/checkpoint` | Simpan snapshot eksplisit |

Contoh request privat:

```json
{
  "sender_id": "opaque-sender-key",
  "message": "Pesan yang ingin diproses secara sementara",
  "private_memory_context": [],
  "consent_granted": false
}
```

`/v1/perceive` memproses input dalam memori kerja scope sender, tetapi menyetel `persist_stimulus=False`. Simpan isi percakapan jangka panjang di vault privat host app. `private_memory_context` adalah data tidak tepercaya dan hanya digunakan untuk menyusun konteks respons pada request itu.

## Keamanan dan privasi

- Default binding `127.0.0.1`; binding non-loopback ditolak tanpa `NADI_API_TOKEN`.
- Jika token disetel, seluruh route memerlukan `Authorization: Bearer <token>`.
- Jangan mengekspos HTTP port secara langsung ke internet. Gunakan jaringan privat atau reverse proxy TLS yang dikonfigurasi dengan benar.
- Hindari mengirim secret, kredensial, atau isi vault ke NADI.
- Satu `data_dir` hanya boleh dibuka satu process. OS file lock mencegah dua writer.
- Backup `data_dir` beserta `.scope-salt`; file salt diperlukan untuk pemetaan scope privat yang stabil.
- Ledger hash-chain mendeteksi perubahan data, tetapi bukan pengganti backup terenkripsi atau kontrol akses filesystem.
- Jangan menafsirkan angka afektif/neuromodulator sebagai emosi manusia nyata.

## Environment opsional

| Variable | Default | Fungsi |
|---|---:|---|
| `NADI_API_TOKEN` | kosong | Wajib untuk binding non-loopback; jika disetel selalu diminta |
| `NADI_MAX_REQUEST_BYTES` | 1 MiB | Batas ukuran body; diklem 16 KiB–4 MiB |
| `NADI_RATE_LIMIT_PER_MINUTE` | 120 | Batas request per IP per menit |
| `NADI_SCOPE_CACHE_LIMIT` | 128 | Cache ledger scope di memori |
| `NADI_DEFAULT_RECALL_TOP_K` | dari config | Default jumlah hasil recall |

## Validasi lokal

```bash
python -m py_compile ac/*.py
python selftest.py
python test_prime.py
```

Suite dasar menguji genesis/hash-chain, recall/konsolidasi, bridge/consent, dan HTTP sidecar. Suite tambahan menguji isolasi scope, non-persistensi pesan privat, lifecycle heartbeat, API perceive/commit, penolakan binding publik tanpa token, process lock, karantina snapshot korup, dan autentikasi Bearer.


## Ocha two-base release compatibility

This is the independent Artificial Consciousness Component base. Ocha Lidya v1.10.57 connects through the secured NADI HTTP API v1. This paired local snapshot is package version `2.1.1`; the supplied workspace has no Git metadata, so no new commit SHA is claimed. When co-located in the Ocha operator workspace, set `OCHA_NADI_SOURCE_DIR=.private/artificial-consciousness-component` to use this source. If unset, Ocha retains its existing remote commit pin `16c2fa6e1b500745f260bcf091284a6e18726883` (package version `2.1.0`). The Python source must remain in this repository/base; do not copy `ac/` into the Ocha Node.js repository.

For an Ocha operator workspace, configure Ocha with `OCHA_NADI_SOURCE_DIR=.private/artificial-consciousness-component`. The nested folder may have its own `.git` directory and remote; the parent Ocha repository must ignore `.private/` completely. Otherwise Ocha downloads the pinned HTTPS GitHub archive into its external component cache. See `OCHA_COMPONENT_RELEASE.json` for release provenance and compatibility metadata.

The model variables are computational state proxies. The package does not demonstrate subjective consciousness, biological emotion, or human physiology.


## v2.1.1 maintenance details

MIMPI now identifies its selected episodic window by a deterministic SHA-256 fingerprint, stores that marker with the generated consolidation blocks, and skips repeat processing of the same window. `EternalMemory.append_many()` writes one derived consolidation batch with one atomic ledger flush; prior ledger records are not modified.

INTEROCEPTION now integrates elapsed time in substeps of at most one second (up to 300 seconds), applies the social interaction impulse once per call, and rejects invalid time deltas. These changes improve numerical stability and repeatability; they are not biological models. See the maintenance report for equations, measured behavior, tests, and follow-up experiments.

For the paired Ocha snapshot, set `OCHA_NADI_SOURCE_DIR=.private/artificial-consciousness-component`. This local package has no Git commit metadata. With that variable unset, the existing Ocha remote commit pin remains the 2.1.0 fallback.

## Maintenance and research evidence

See [`ARTIFICIAL_CONSCIOUSNESS_MAINTENANCE_REPORT.md`](ARTIFICIAL_CONSCIOUSNESS_MAINTENANCE_REPORT.md) for the subsystem review, measured stability findings, test evidence and follow-up experiments.


## Ocha operator workspace and independent Git publishing

When paired with Ocha v1.10.57, the AC source is co-located at `.private/artificial-consciousness-component` inside the Ocha operator workspace. This directory becomes an independent nested Git checkout of `razzaqinspires/artificial-consciousness-component` on `main`; it is never staged by the parent Ocha repository. Run `npm run ac:git:setup` from the Ocha root to clone the canonical remote history before applying the local source snapshot. Authentication uses a separate `AC_GITHUB_PAT` with least-privilege Contents read/write access.

The AC watcher excludes `.git`, `.env` (except the safe `.env.example` template), local configuration, credentials directories, private keys/certificates, database files, NADI ledgers and runtime state, caches, virtual environments and build outputs. It rejects symlinks, special files, secret-pattern matches, noncanonical remotes and divergent branch histories. The watcher runs only while Ocha's Node.js process is alive. The model source version remains v2.1.1 in this operations-only change; no kernel equations or subjective-consciousness claims are changed.
