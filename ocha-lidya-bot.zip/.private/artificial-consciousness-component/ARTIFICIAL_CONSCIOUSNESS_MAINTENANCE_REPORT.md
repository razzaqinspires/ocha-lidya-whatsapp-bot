# Artificial Consciousness Maintenance Report — paired snapshot 2026-11-26

## Release identity and provenance

- Component: `ac-kernel-nadi@2.1.1`.
- Compatible Ocha base: `ocha-lidya-whatsapp-bot@1.10.57`.
- Integration contract: secured NADI HTTP API v1 (unchanged).
- Source repository: `https://github.com/razzaqinspires/artificial-consciousness-component`.
- Source workspace had no `.git` directory. A commit SHA is therefore unavailable and is deliberately recorded as `null`; this package is a paired local workspace snapshot, not a claimed upstream commit or GitHub push.
- Ocha's prior remote pin `16c2fa6e1b500745f260bcf091284a6e18726883` remains the fallback when `OCHA_NADI_SOURCE_DIR` is empty. To activate this paired 2.1.1 snapshot, configure `OCHA_NADI_SOURCE_DIR=.private/artificial-consciousness-component`.

## Subsystem review

| Subsystem | Source inspected | Review focus | Status |
|---|---|---|---|
| NADI heartbeat | `ac/nadi.py`, `ac/kernel.py::start_heartbeat` | Oscillator, BPM, elapsed-time coalescing, drift and lifecycle | REVIEWED; existing scheduler retained |
| INTEROCEPTION | `ac/intero.py::update`, `ac/kernel.py::tick` | Energy, thermal, social and allostatic integration; large-delta stability | IMPROVED and TESTED |
| RASA | `ac/rasa.py::RasaAppraiser.appraise` | Synthetic valence/arousal/dominance and appraisal bounds | REVIEWED; no source change |
| NEURO | `ac/neuro.py::NeuroField.step` | Neuromodulator ranges, coupling and plasticity gain | REVIEWED; no source change |
| KEHENDAK | `ac/kehendak.py::Kehendak.deliberate` | Expected-free-energy evaluation, risk, ambiguity and policy selection | REVIEWED; no source change |
| MIMPI | `ac/mimpi.py::Dreamer.sleep_cycle`, `ac/ingat.py::EternalMemory.append_many` | Window fingerprinting, duplicate cycles and atomic batch commit | IMPROVED and TESTED |
| DIRI | `ac/diri.py::Diri.update` | Predictive self-model, agency and continuity proxies | REVIEWED; no source change |
| PANGGUNG | `ac/panggung.py::Panggung.compete_and_broadcast` | Workspace competition and attention selection | REVIEWED; no source change |
| METRICS / MEMORY | `ac/metrics.py`, `ac/ingat.py`, `ac/kernel.py` | Counters, SHA-256 chain, append-only history and private scopes | REVIEWED; append-only invariant retained |
| HTTP sidecar | `ac/server.py::create_sidecar_server` | Loopback binding, Bearer auth, body bounds, API compatibility | REGRESSION TESTED; API v1 unchanged |

## Improvements implemented

### 1. MIMPI repeat-window idempotency

**Problem.** A repeated `.nadi sleep` against an unchanged set of recent episodic blocks previously appended another REM insight, and `Kernel.sleep()` also applied another interoceptive recovery. A restart did not remove the duplicate-cycle risk.

**Algorithm.** `Dreamer.sleep_cycle()` now calculates a SHA-256 fingerprint from the ordered `block_hash` values in its selected episodic window. Each generated NREM/REM record stores a `mimpi-window-sha256:<digest>` tag. Before processing, MIMPI checks the append-only ledger for that marker. An already processed window returns `status=skipped`, `reason=window_already_consolidated`, and `idempotent=true`; `Kernel.sleep()` consequently does not restore energy or increment sleep-cycle counters again.

**Atomicity.** `EternalMemory.append_many()` seals all related derived blocks with a continuous `prev_hash` chain and commits them through one atomic ledger flush. On write failure, the in-memory list is restored. Existing historical blocks are never edited or removed.

**Window semantics.** When a new episodic block changes the selected window fingerprint, a new consolidation pass is allowed. Older v2.1.0 consolidation blocks have no fingerprint marker; the first v2.1.1 pass over such a window cannot prove that it was previously consolidated, so it may create one new marked pass. No historical migration or destructive rewrite is attempted.

### 2. INTEROCEPTION bounded numerical integration

**Problem.** The existing explicit Euler coefficients could overshoot when a delayed heartbeat supplied a large `dt`. A baseline probe recorded `thermal_load=1.0`, `allostatic_load=1.0`, and `cool_drive=1.0` for `dt=300`; the same initial state at `dt=1` had `thermal_load=0.204`, `allostatic_load=0.1372`, and `cool_drive=0.0`.

**Algorithm.** `Interoception.update()` now splits a valid elapsed delta into substeps no larger than one second. Energy, thermal load, social recovery and allostatic load are updated on each substep. `social_interaction` remains a one-time impulse per call and is not multiplied by the number of substeps. The permitted delta is finite and within `0..300` seconds, matching the kernel heartbeat's existing elapsed-time coalescing ceiling. `Kernel.tick()` validates this before mutating NADI or interoceptive state.

**Numerical regression.** A single `dt=300` update is compared with a reference made from one initial social impulse and 299 additional one-second steps; all five tracked state variables match within `1e-10`. In a fixed-state probe, the updated `dt=300` run produced `thermal_load=0.2987`, `allostatic_load=0.0186`, and `cool_drive=0.0682` rather than saturating all three to `1.0`. Invalid negative, infinite, NaN and over-limit deltas are rejected.

## Before / after evidence

| Experiment | Baseline v2.1.0 | Paired v2.1.1 |
|---|---|---|
| Repeat same MIMPI window | Each repeated sleep appended another insight | Second call skipped; no new blocks or repeated homeostatic recovery |
| Restart then repeat same MIMPI window | No durable idempotency marker | Ledger tag survives restart; repeated window skipped |
| New episode after completed window | Not separately fingerprinted | Different window digest allows new consolidation |
| `dt=300` integration | `thermal_load=1.0`, `allostatic_load=1.0`, `cool_drive=1.0` | `thermal_load=0.2987`, `allostatic_load=0.0186`, `cool_drive=0.0682`; matches 1 Hz reference |
| Invalid `dt` | No explicit kernel-level finite/range guard | Rejected before tick state changes |

## Test results

- `python -m py_compile ac/*.py`: PASS.
- `python selftest.py`: 6/6 PASS (includes repeat-window idempotency across restart and invalid-delta non-mutation).
- `python test_prime.py`: 10/10 PASS (includes 300-second reference equivalence, 1-hour 1 Hz stability, privacy, lifecycle, process lock, corrupt snapshot quarantine and HTTP auth).
- Ocha local HTTP API v1 integration: recorded in paired Ocha report; uses sibling local component source.

## Remaining limitations and next research objectives

1. **INTEROCEPTION exact/exponential integration:** current one-second substeps improve stability but remain an Euler approximation. Compare against closed-form relaxation for the linear terms and evaluate numerical error over variable heartbeat gaps.
2. **NADI drift recovery:** test restart, wall-clock jumps, monotonic-clock behavior and repeated scheduler stalls. Verify heartbeat count and phase remain bounded after recoveries.
3. **NEURO coupling:** run sensitivity and boundedness sweeps across simultaneous arousal, stress and plasticity extremes.
4. **MIMPI overlapping windows:** evaluate overlapping batch windows and repeated short cycles to quantify semantic duplication beyond exact-window idempotency.
5. **PANGGUNG / DIRI coherence:** add deterministic competition/recovery traces and consistency metrics; do not equate proxies with subjective awareness.
6. **Metrics integrity:** add restart and long-duration checks for counter consistency, tick latency aggregation and memory-chain correlation.
7. **Operational validation:** run the paired 2.1.1 component on the actual VPS and inspect `.nadi status`, `.nadi pulse`, `.nadi sleep`, `.nadi verify` and the public kernel dashboard. These local tests are not a live VPS or WhatsApp test.

## Claim boundary

All variables described as affect, neuromodulators, homeostasis, sleep, agency, coherence or consciousness are synthetic computational proxies. The implementation does not establish biological physiology, sentience, subjective experience or phenomenal consciousness. No quantum computation is implemented.


## Operational pairing review — Ocha v1.10.57

- AC v2.1.1 source and computational algorithms were reviewed for the two-repository auto-push integration. No AC kernel equation, state transition, MIMPI algorithm, INTEROCEPTION algorithm, NADI heartbeat behavior, memory ledger, or HTTP API v1 contract was changed in this Ocha release.
- The component is deployed as an independently versioned nested Git checkout at `.private/artificial-consciousness-component`. The parent Ocha Git repository excludes `.private/`; the nested repository has its own `origin` and branch `main`.
- Auto-push changes repository operations and does not imply a new AC model capability or a claim of subjective consciousness. AC remains v2.1.1 until a separate tested AC behavior change warrants a version increment.
- Next AC review: compare exact/exponential INTEROCEPTION integration against the current one-second Euler substeps; test heartbeat drift recovery; measure MIMPI overlapping-window duplicate semantics; run NEURO coupling sensitivity sweeps.


## Operational publishing review — Ocha v1.10.57 (2026-11-27)

The AC base is co-located under the Ocha operator-only path `.private/artificial-consciousness-component`, but retains a distinct nested Git root targeting `razzaqinspires/artificial-consciousness-component` (`main`). Its credential is separate from the Ocha credential (`AC_GITHUB_PAT`). The AC watcher and packaging filter deny `.env` files (except `.env.example`), credentials folders, `.ssh`/`.aws`, service-account files, private keys/certificates, SQLite/DB files, NADI ledger/runtime state, caches, virtual environments, build output, symlinks and special files. The parent Ocha Git publication path rejects any still-tracked `.private` entries; the AC watcher stages only paths relative to the nested root. No force-push is used.

This is an operations-only review. AC model sources remain v2.1.1 and their equations/behavior are unchanged. The source archive still has no `.git` metadata, and remote repository access could not be verified from the source-only workspace; the operator's `npm run ac:git:setup` must clone and reconcile the canonical remote before auto-push can be considered active. No actual GitHub commit or push is claimed here.
