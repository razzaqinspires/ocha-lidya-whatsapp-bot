"""Interoception — Homeostasis and Allostatic Load regulation."""

from __future__ import annotations

import math
from dataclasses import asdict, dataclass
from typing import Any, Dict

from .config import ACConfig
from .util import clamp


@dataclass
class Interoception:
    """Tracks internal physiological/computational variables and allostatic strain."""

    energy: float = 0.85
    thermal_load: float = 0.20
    memory_pressure: float = 0.15
    social_battery: float = 0.70
    allostatic_load: float = 0.15

    def update(
        self,
        config: ACConfig,
        dt: float = 1.0,
        cognitive_effort: float = 0.2,
        social_interaction: float = 0.0,
        memory_count: int = 0,
    ) -> Dict[str, float]:
        """Integrate homeostatic drift, metabolic cost, and allostatic error."""
        # The operational heartbeat coalesces missed time to at most 300 seconds.
        # Reject invalid/out-of-contract deltas before changing any state.
        delta = float(dt)
        if not math.isfinite(delta) or delta < 0.0 or delta > 300.0:
            raise ValueError("dt must be finite and within 0..300 seconds")

        effort = clamp(cognitive_effort)
        # A social interaction is an impulse, not a per-substep rate. Apply it once,
        # then integrate its recovery alongside the continuous state equations.
        self.social_battery = clamp(self.social_battery + 0.03 * float(social_interaction))
        self.memory_pressure = clamp(min(1.0, memory_count / 2500.0))

        max_step = 1.0
        substeps = max(1, math.ceil(delta / max_step))
        step_dt = delta / substeps
        for _ in range(substeps):
            # Time-normalized homeostasis: one-second Euler steps keep the linear
            # relaxation terms stable even after a long heartbeat interruption.
            self.energy = clamp(
                self.energy
                + (config.energy_setpoint - self.energy) * 0.005 * step_dt
                - 0.00015 * effort * step_dt
            )
            self.thermal_load = clamp(
                self.thermal_load
                + 0.003 * effort * step_dt
                - 0.04 * (self.thermal_load - config.thermal_setpoint) * step_dt
            )
            self.social_battery = clamp(
                self.social_battery
                - 0.005 * (self.social_battery - config.social_setpoint) * step_dt
            )

            # Compute current synthetic homeostatic drive errors.
            e_err = abs(config.energy_setpoint - self.energy)
            t_err = max(0.0, self.thermal_load - config.thermal_setpoint)
            m_err = max(0.0, self.memory_pressure - 0.65)
            instant_strain = clamp(0.45 * e_err + 0.35 * t_err + 0.20 * m_err)
            self.allostatic_load = clamp(
                self.allostatic_load + 0.10 * (instant_strain - self.allostatic_load) * step_dt
            )

        return self.drives(config)

    def drives(self, config: ACConfig) -> Dict[str, float]:
        """Return normalized homeostatic motivational drives."""
        return {
            "rest_drive": round(clamp((1.0 - self.energy) * 0.7 + self.allostatic_load * 0.3), 4),
            "cool_drive": round(clamp(max(0.0, self.thermal_load - config.thermal_setpoint) * 1.4), 4),
            "consolidate_drive": round(clamp(self.memory_pressure * 0.8 + self.allostatic_load * 0.2), 4),
            "engage_drive": round(clamp(self.energy * 0.6 + (1.0 - self.allostatic_load) * 0.4), 4),
        }

    def recover_during_sleep(self, quality: float = 0.8) -> None:
        """Restore energy and reduce allostatic load after NREM/REM sleep consolidation."""
        q = clamp(quality)
        self.energy = clamp(self.energy + 0.28 * q)
        self.thermal_load = clamp(self.thermal_load * (1.0 - 0.35 * q))
        self.allostatic_load = clamp(self.allostatic_load * (1.0 - 0.45 * q))

    def to_dict(self) -> Dict[str, Any]:
        return {k: round(v, 4) for k, v in asdict(self).items()}

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Interoception":
        valid = {f.name for f in cls.__dataclass_fields__.values()}
        return cls(**{k: float(v) for k, v in data.items() if k in valid})
