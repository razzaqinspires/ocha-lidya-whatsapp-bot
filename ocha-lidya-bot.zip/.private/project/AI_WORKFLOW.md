# Private Ocha Engineering Workflow

1. Inspect current source, README, changelog, architecture docs, package metadata and tests before changes. Treat repository code as the source of truth.
2. Keep Ocha and Artificial Consciousness Component as two independent source bases. Pin the component commit and HTTP API version.
3. Never copy NADI Python source into Ocha. Ocha contains only the loader, HTTP client, health contract, configuration and lifecycle integration.
4. Preserve the four private Ocha modules byte-identically under `.private/ocha-private-runtime/`. Validate their size and SHA-256 before and after migration. Never run Prettier or modify original source.
5. Public compatibility facades must work without `.private`; private mode must fail closed when `OCHA_PRIVATE_RUNTIME_REQUIRED=1`.
6. Keep `.private`, credentials, session files, database/runtime state, ACIE vault/provider registries, generated commands and logs out of Git. Run `npm run security:publication` before staging.
7. Do not assume `.gitignore` untracks files already committed or erases Git history. Check `git status`, `git ls-files` and staged paths. Never rewrite history without explicit owner approval.
8. For ACIE, inspect provider status, activation gate, protocol test, sandbox health, circuit breaker, command registry and aliases. Only provider health from actual persisted checks is evidence; do not claim a live probe without executing it.
9. For the Artificial Consciousness Maintenance Cycle, review the NADI, interoception, affect, neuromodulation, deliberation, dreaming, self-model, workspace, metrics and memory code. Do not claim subjective consciousness.
10. Run Ocha syntax checks, full regression tests, Python component tests, documentation checks and packaging-integrity checks. Live WhatsApp and VPS validations must be reported separately.
11. Every main release emits two base archives, version/commit information, SHA-256 checksums, changelog entries and compatible API details.

12. The two-base release script builds the Ocha operator archive and the independent AC component archive. Never upload the Ocha operator bundle containing `.private/` to a public repository.
13. Run `npm run ops:audit-runtime` on the real VPS for persisted dynamic ACIE state; use the approved `.acie provider test` flow for external adapter protocol checks. A local `NO_RUNTIME_DATA` report is not a VPS result.
14. Run `npm run test:nadi-integration` for local HTTP API v1 integration. This does not replace a live WhatsApp/authorized VPS test.
15. Preserve the maintenance findings and experiment baselines in the Artificial Consciousness Maintenance Report; do not alter the independent component pin without a committed/released component version and matching Ocha pin update.

16. Keep the repository root minimal: only `README.md` may be a root Markdown file. Put project structure documentation under `docs/architecture/`, changelog indexes under `docs/releases/`, and generated operator metadata under `.release/`. Keep only package/tooling JSON such as `package.json` and `.prettierrc.json` at root.

17. Treat `.env.example` as generated, source-verified configuration documentation. Before a release, run `npm run env:sync`, `npm run env:check`, `npm test`, and `npm run security:publication`; inspect dynamic environment reads and dotenv load points in `docs/ENVIRONMENT_VARIABLES.md`. Never read, copy, or publish actual `.env` values.
