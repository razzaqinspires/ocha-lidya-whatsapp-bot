# Rizkyrohan Text Canvas — ACIE Intake Bundle

This bundle contains the exact original `index.mjs` contribution under `original/`, plus a separate receipt. Do not edit or reformat the original file.

## Integrity

- SHA-256: `30e451e96eedfa9c755b5f23f7825e19ea059749707cfd8b5878f72f7b4f4a43`
- Size: 3460 bytes
- Contributor: Rizkyrohan
- License: pending information

## Intake on the Ocha VPS

Extract this bundle to a directory outside the Ocha repository, for example `/srv/incoming/rizkyrohan-text-canvas-v1`. Then run intake against the `original` subdirectory only:

```bash
npm run acie:intake -- \
  --source /srv/incoming/rizkyrohan-text-canvas-v1/original \
  --contributor-id rizkyrohan \
  --contributor-name Rizkyrohan \
  --name text-canvas-generator \
  --project-id ocha-lidya-bot \
  --attribution "Original implementation credited to Rizkyrohan; see ACIE_RECEIPT.json"
```

Do not pass the bundle root as `--source`, because the receipt and this README are metadata, not contributed source files. The resulting provider must remain quarantined.

The generated `.textimage` / `.timg` command is a no-argument draft because the source hardcodes its text. It must not appear in the public menu until assets are licensed and available, the external bridge is implemented and tested, the sandbox is validated, and owner approval is recorded.

The font and background are not included. The GitHub references checked for them expose no license metadata or `LICENSE` file, so permission and local snapshotting remain pending.
