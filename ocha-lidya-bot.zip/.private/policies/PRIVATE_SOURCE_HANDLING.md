# Private source handling — local operator copy only

This file is an operational handoff note. It is intentionally excluded from public publication.

The following modules are designated local/private by the repository owner and preserved under `.private/ocha-private-runtime/`:
- `src/lib/helpers.js`
- `src/lib/freply.js`
- `src/lib/serializ_simple.js`
- `src/plugins/owner/message-lab.js`

Their immutable original bytes and runtime copies remain present in this complete operator ZIP. Public source paths contain adapters only. The publication firewall and `.gitignore` exclude `.private/ocha-private-runtime/` from future Git staging. Do not upload this ZIP as a public release artifact.

Important: these modules existed in earlier public Git history. Future ignore rules do not erase public history. The private-runtime extraction is implemented for the local operator bundle. A clean public clone runs the public compatibility adapters until an operator supplies the private package. Any history rewrite requires explicit owner approval and coordinated clone refresh.
