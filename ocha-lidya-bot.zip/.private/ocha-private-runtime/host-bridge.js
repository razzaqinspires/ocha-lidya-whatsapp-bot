import fs from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

const ALLOWED_HOST_MODULES = new Set([
  'src/lib/contact-card.js',
  'src/core/reply-sessions.js',
  'src/lib/message-text.js',
  'src/lib/native-flow-registry.js',
  'src/core/logger.js',
  'src/plugins/owner/message-test-catalog.js'
]);

let configuredRoot = '';

export async function configureHostBridge(hostRoot) {
  if (typeof hostRoot !== 'string' || !hostRoot.trim()) {
    throw new TypeError('hostRoot is required to connect the private runtime to Ocha public services.');
  }
  const resolved = await fs.realpath(path.resolve(hostRoot));
  const required = ['package.json', 'src/index.js', 'src/core/plugin-loader.js'];
  for (const item of required) await fs.access(path.join(resolved, item));
  configuredRoot = resolved;
  return configuredRoot;
}

export async function importHostModule(relativePath) {
  const normalized = String(relativePath || '').replaceAll('\\', '/');
  if (!ALLOWED_HOST_MODULES.has(normalized)) {
    throw new Error(`Private runtime requested a non-allowlisted host module: ${normalized || '(empty)'}`);
  }
  if (!configuredRoot) throw new Error('Private runtime host bridge has not been configured.');
  const absolute = path.resolve(configuredRoot, normalized);
  if (!absolute.startsWith(`${configuredRoot}${path.sep}`)) {
    throw new Error('Host module path escaped the configured project root.');
  }
  await fs.access(absolute);
  return import(pathToFileURL(absolute).href);
}

export function getConfiguredHostRoot() {
  return configuredRoot;
}
