import { importHostModule } from '../../../host-bridge.js';
const host = await importHostModule('src/plugins/owner/message-test-catalog.js');
export const NUMBERED_TESTS = host.NUMBERED_TESTS;
export const sendMessageTestMenu = host.sendMessageTestMenu;
