import { importHostModule } from '../../host-bridge.js';
const host = await importHostModule('src/core/logger.js');
export const logger = host.logger;
export const baileysLogger = host.baileysLogger;
export const configureLogger = host.configureLogger;
