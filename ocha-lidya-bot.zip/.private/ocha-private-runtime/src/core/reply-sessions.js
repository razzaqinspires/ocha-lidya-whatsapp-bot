import { importHostModule } from '../../host-bridge.js';
const host = await importHostModule('src/core/reply-sessions.js');
export const registerReplySession = host.registerReplySession;
export const dispatchReplySession = host.dispatchReplySession;
export const getReplySessionStats = host.getReplySessionStats;
