import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import crypto from 'node:crypto';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { verifyPrivateSourceManifest } from '../index.js';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const files = [
  'src/lib/helpers.js',
  'src/lib/freply.js',
  'src/lib/serializ_simple.js',
  'src/plugins/owner/message-lab.js'
];

test('runtime source is byte-identical to immutable intake copy', async () => {
  for (const relative of files) {
    const runtime = await fs.readFile(path.join(root, relative));
    const original = await fs.readFile(path.join(root, 'original-source', relative));
    assert.deepEqual(runtime, original, `${relative} changed after preservation`);
    const digest = crypto.createHash('sha256').update(original).digest('hex');
    assert.match(digest, /^[a-f0-9]{64}$/);
  }
});

test('private plugin bridge files exist outside the original source paths', async () => {
  for (const relative of [
    'src/lib/contact-card.js', 'src/core/reply-sessions.js', 'src/lib/message-text.js',
    'src/lib/native-flow-registry.js', 'src/core/logger.js', 'src/plugins/owner/message-test-catalog.js'
  ]) await fs.access(path.join(root, relative));
});


test('runtime verifies the exact private source manifest before importing original modules', async () => {
  const result = await verifyPrivateSourceManifest();
  assert.deepEqual(result, { verified: true, files: 4 });
});
