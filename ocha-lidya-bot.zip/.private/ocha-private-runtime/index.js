import fs from 'node:fs/promises';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { configureHostBridge } from './host-bridge.js';

export const PRIVATE_RUNTIME_PACKAGE = '@razzaqventures/ocha-private-runtime';
export const PRIVATE_RUNTIME_VERSION = '1.10.58';

const PACKAGE_ROOT = path.dirname(fileURLToPath(import.meta.url));
const REQUIRED_PRIVATE_SOURCE_PATHS = Object.freeze([
  'src/lib/helpers.js',
  'src/lib/freply.js',
  'src/lib/serializ_simple.js',
  'src/plugins/owner/message-lab.js'
]);

let runtimePromise;


/** Verify immutable runtime bytes and their retained intake receipts before importing source. */
export async function verifyPrivateSourceManifest() {
  const packageJson = JSON.parse(await fs.readFile(path.join(PACKAGE_ROOT, 'package.json'), 'utf8'));
  const manifest = JSON.parse(await fs.readFile(path.join(PACKAGE_ROOT, 'manifest.json'), 'utf8'));
  if (packageJson.name !== PRIVATE_RUNTIME_PACKAGE || packageJson.private !== true || packageJson.version !== PRIVATE_RUNTIME_VERSION) {
    throw new Error('Private runtime package metadata does not match the expected private package identity/version.');
  }
  if (manifest.package !== PRIVATE_RUNTIME_PACKAGE || manifest.version !== PRIVATE_RUNTIME_VERSION || !Array.isArray(manifest.files)) {
    throw new Error('Private runtime source manifest is missing or incompatible.');
  }
  const byPath = new Map(manifest.files.map(item => [item.sourcePath, item]));
  const packageRealRoot = await fs.realpath(PACKAGE_ROOT);
  if (REQUIRED_PRIVATE_SOURCE_PATHS.some(relative => !byPath.has(relative)) || byPath.size !== REQUIRED_PRIVATE_SOURCE_PATHS.length) {
    throw new Error('Private runtime source manifest does not contain the exact required source set.');
  }
  for (const relative of REQUIRED_PRIVATE_SOURCE_PATHS) {
    const item = byPath.get(relative);
    for (const candidate of [item.runtimePath, item.originalPath]) {
      const absolute = path.resolve(PACKAGE_ROOT, candidate);
      if (!absolute.startsWith(`${PACKAGE_ROOT}${path.sep}`)) throw new Error(`Private runtime manifest path escaped package root: ${candidate}`);
      const realAbsolute = await fs.realpath(absolute);
      if (!realAbsolute.startsWith(`${packageRealRoot}${path.sep}`)) throw new Error(`Private runtime manifest symlink escaped package root: ${candidate}`);
      const stat = await fs.stat(realAbsolute);
      if (!stat.isFile()) throw new Error(`Private runtime manifest path is not a file: ${candidate}`);
      const bytes = await fs.readFile(realAbsolute);
      const digest = createHash('sha256').update(bytes).digest('hex');
      if (digest !== item.sha256 || bytes.byteLength !== item.sizeBytes) {
        throw new Error(`Private runtime integrity verification failed for ${candidate}.`);
      }
    }
  }
  return { verified: true, files: REQUIRED_PRIVATE_SOURCE_PATHS.length };
}

/**
 * Load the immutable private feature modules and bind their small set of public
 * host dependencies through an explicit, allowlisted adapter bridge.
 */
export function createPrivateRuntime({ hostRoot } = {}) {
  if (runtimePromise) return runtimePromise;
  runtimePromise = (async () => {
    await verifyPrivateSourceManifest();
    await configureHostBridge(hostRoot);
    const [serializerModule, helpersModule, freplyModule, messageLabModule] = await Promise.all([
      import('./src/lib/serializ_simple.js'),
      import('./src/lib/helpers.js'),
      import('./src/lib/freply.js'),
      import('./src/plugins/owner/message-lab.js')
    ]);

    const serializer = serializerModule.default;
    const helpers = helpersModule.default;
    const freply = freplyModule.default;
    const messageLab = messageLabModule.default;

    const requiredSerializerFunctions = [
      'serialize', 'extendSocket', 'trackSentMessageId', 'setOutgoingMessageObserver'
    ];
    for (const name of requiredSerializerFunctions) {
      if (typeof serializer?.[name] !== 'function') {
        throw new Error(`Private runtime serializer contract missing function: ${name}`);
      }
    }
    if (typeof helpers?.AIRich !== 'function' || typeof helpers?.ButtonBuilder !== 'function') {
      throw new Error('Private runtime helpers contract is incompatible.');
    }
    if (typeof freply?.createFakeReply !== 'function') {
      throw new Error('Private runtime fake-reply contract is incompatible.');
    }
    if (!messageLab?.name || typeof messageLab.execute !== 'function') {
      throw new Error('Private message-test plugin contract is incompatible.');
    }
    if (messageLab.name !== 'test' || messageLab.ownerOnly !== true || messageLab.privateOnly !== true) {
      throw new Error('Private message-test plugin must remain owner-only and private-only.');
    }

    return Object.freeze({
      available: true,
      apiVersion: 1,
      packageName: PRIVATE_RUNTIME_PACKAGE,
      version: PRIVATE_RUNTIME_VERSION,
      serializer,
      helpers,
      freply,
      plugins: Object.freeze([messageLab]),
      capabilities: Object.freeze([
        'baileys_message_serialization',
        'lid_and_pn_identity_resolution',
        'native_flow_interactive_messages',
        'rich_message_builders',
        'fake_reply_catalogue',
        'media_download_helpers',
        'owner_private_message_test_lab'
      ])
    });
  })();
  return runtimePromise;
}

export function getPrivateRuntimePackageInfo() {
  return {
    name: PRIVATE_RUNTIME_PACKAGE,
    version: PRIVATE_RUNTIME_VERSION,
    private: true,
    api: 1
  };
}
