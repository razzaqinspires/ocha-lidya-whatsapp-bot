# Ocha Lidya Private Runtime — 1.10.58 (source package metadata)

This is a **separate private package**, not a subdirectory that should be committed to the public Ocha Lidya bot repository. Keep this package in a private repository or a host-only location outside the public checkout.

## Contents

The four original source files are retained byte-for-byte at the same runtime paths and duplicated under `original-source/` as an immutable intake receipt:

- `src/lib/helpers.js`
- `src/lib/freply.js`
- `src/lib/serializ_simple.js`
- `src/plugins/owner/message-lab.js`

`manifest.json` records the original archive hash, source hashes, sizes and intake provenance. `src/core/*` and the non-original `src/lib/*` bridge files are adapters to public host modules; they do not duplicate those host implementations. The four original files in `src/` and their receipts in `original-source/` are immutable and must never be formatted, transformed, or regenerated in place. Formatting commands target only adapter/manifest files.

## Install into a public bot checkout

1. Place this package in a private directory outside the public checkout, for example `/opt/ocha-lidya-private-runtime`.
2. From the bot root, run:

   ```bash
   npm run private-runtime:install -- /opt/ocha-lidya-private-runtime
   ```

   This installs the package under `node_modules/@razzaqventures/ocha-private-runtime`; the source package itself remains outside the public repository.
3. Verify it:

   ```bash
   npm run private-runtime:status
   ```
4. Restart Ocha. The public adapter discovers the package automatically. The installer validates every original source checksum before invoking npm.

Do not copy the contents into `src/`, and do not add the private package as a public Git submodule or public npm dependency.

## Runtime modes

- **Private runtime installed:** the original serializer, rich builders, fake-reply engine and owner/private `.test` plugin are loaded through the package contract.
- **Private runtime absent:** the bot starts with its public compatibility serializer. Basic message parsing, text replies, reactions, contacts, basic media downloads and textual UI fallback remain available. Native Flow, rich message builders, historical fake replies, call control and `.test` are unavailable in this mode and are reported as such; the bot must not claim those private capabilities are active.
- Set `OCHA_PRIVATE_RUNTIME_REQUIRED=1` to make absence or incompatibility a startup error on an operator deployment that requires the private feature set. Leave it unset/`0` for a public installation.

## Host bridge contract

The private package can import only these host modules through `host-bridge.js`:

- `src/lib/contact-card.js`
- `src/core/reply-sessions.js`
- `src/lib/message-text.js`
- `src/lib/native-flow-registry.js`
- `src/core/logger.js`
- `src/plugins/owner/message-test-catalog.js`

The allowlist is explicit. The host root is verified before imports. The private plugin is validated for the exact `test` command, `ownerOnly: true`, and `privateOnly: true`; collisions are rejected by the public plugin loader.

## Validation

Run `npm run check`, `npm test`, `npm run format:check` in the bot, and `npm run check`, `npm test`, `npm run format:check` in this private package after installing its declared peer dependency and Prettier dev tool. Live WhatsApp rendering and media/call behavior still require a controlled test account.
