import fs from 'node:fs/promises';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const manifest = JSON.parse(await fs.readFile(path.join(root, 'manifest.json'), 'utf8'));
const failures = [];
for (const item of manifest.files || []) {
  for (const relative of [item.runtimePath, item.originalPath]) {
    const absolute = path.resolve(root, relative);
    if (!absolute.startsWith(`${root}${path.sep}`)) {
      failures.push(`${relative}: path escaped package root`);
      continue;
    }
    const bytes = await fs.readFile(absolute);
    const digest = createHash('sha256').update(bytes).digest('hex');
    if (digest !== item.sha256) failures.push(`${relative}: SHA-256 mismatch`);
    if (bytes.byteLength !== item.sizeBytes) failures.push(`${relative}: size mismatch`);
  }
}
if (failures.length) {
  console.error('Private source integrity verification failed:');
  for (const issue of failures) console.error(`- ${issue}`);
  process.exitCode = 1;
} else {
  console.log(`Verified ${manifest.files.length} immutable private source modules and their retained receipts.`);
}
